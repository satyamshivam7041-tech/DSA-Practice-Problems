Question: Q10
Topic: 01_Arrays
Student Name: Satyam Shivam
Roll Number: CH.SC.U4CSE25242
Question source: original assignment PDF
Test artifacts: available files from the verified solution workspace
