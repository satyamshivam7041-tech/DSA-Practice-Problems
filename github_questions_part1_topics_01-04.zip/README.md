# DSA 100 Assignment — Questions & Test Cases

Student Name: Satyam Shivam  
Roll Number: CH.SC.U4CSE25242

This folder contains the 100 original assignment question PDFs, organized
by topic and question number, together with the test inputs, expected outputs,
and actual outputs generated during verification.

## Topics
1. Arrays
2. Stack
3. Queue
4. Linked List
5. Searching
6. Sorting
7. Tree 1
8. Tree 2
9. Graph
10. Hashing

## Per-question contents
- `Question.pdf` — original assignment question
- `test1_input.txt`
- `test1_expected.txt`
- `test1_actual.txt`
- `test2_input.txt`
- `test2_expected.txt`
- `test2_actual.txt`

The C solutions are stored separately in the Git submission package.
