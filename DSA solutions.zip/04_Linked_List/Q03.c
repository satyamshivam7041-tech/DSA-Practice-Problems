/*
 * 04_Linked_List Q03: Sorted insert in Circular Linked List
 * Mandatory: struct Node *next;, void sortedInsert(struct Node** head_ref, struct Node* new_node)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

void sortedInsert(struct Node** head_ref, struct Node* new_node) {
    struct Node* current = *head_ref;
    
    if (current == NULL) {
        new_node->next = new_node;
        *head_ref = new_node;
    } else if (current->data >= new_node->data) {
        while (current->next != *head_ref)
            current = current->next;
        current->next = new_node;
        new_node->next = *head_ref;
        *head_ref = new_node;
    } else {
        while (current->next != *head_ref && current->next->data < new_node->data)
            current = current->next;
        new_node->next = current->next;
        current->next = new_node;
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    struct Node* head = NULL;
    for (int i = 0; i < n; i++) {
        int val;
        scanf("%d", &val);
        struct Node* temp = (struct Node*)malloc(sizeof(struct Node));
        temp->data = val;
        temp->next = NULL;
        sortedInsert(&head, temp);
    }
    
    if (head != NULL) {
        struct Node* cur = head;
        int first = 1;
        do {
            if (!first) printf(" ");
            printf("%d", cur->data);
            first = 0;
            cur = cur->next;
        } while (cur != head);
    }
    printf("\n");
    return 0;
}
