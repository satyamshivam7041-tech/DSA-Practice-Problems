/*
 * 04_Linked_List Q05: Delete alternate nodes of linked list
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

void deleteAlt(struct Node *head) {
    if (head == NULL) return;
    struct Node *prev = head;
    struct Node *node = head->next;
    
    while (prev != NULL && node != NULL) {
        prev->next = node->next;
        free(node);
        prev = prev->next;
        if (prev != NULL)
            node = prev->next;
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    struct Node *head = NULL, *tail = NULL;
    for (int i = 1; i <= n; i++) {
        struct Node *temp = (struct Node*)malloc(sizeof(struct Node));
        temp->data = i;
        temp->next = NULL;
        if (!head) head = tail = temp;
        else { tail->next = temp; tail = temp; }
    }
    
    deleteAlt(head);
    
    struct Node *cur = head;
    int first = 1;
    while (cur) {
        if (!first) printf(" ");
        printf("%d", cur->data);
        first = 0;
        cur = cur->next;
    }
    printf("\n");
    return 0;
}
