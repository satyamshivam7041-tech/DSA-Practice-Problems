/*
 * 04_Linked_List Q06: GetNth element in linked list
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

void push(struct Node** head_ref, int new_data) {
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
    new_node->data = new_data;
    new_node->next = (*head_ref);
    (*head_ref) = new_node;
}

int GetNth(struct Node* head, int index) {
    struct Node* current = head;
    int count = 1;
    while (current != NULL) {
        if (count == index)
            return current->data;
        count++;
        current = current->next;
    }
    return -1;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    struct Node* head = NULL;
    for (int i = 0; i < n; i++) {
        int val;
        scanf("%d", &val);
        push(&head, val);
    }
    
    int index;
    scanf("%d", &index);
    
    printf("Linked list:");
    struct Node* cur = head;
    while (cur) {
        printf("-->%d", cur->data);
        cur = cur->next;
    }
    printf("\n");
    
    printf("Node at index=%d:%d\n", index, GetNth(head, index));
    return 0;
}
