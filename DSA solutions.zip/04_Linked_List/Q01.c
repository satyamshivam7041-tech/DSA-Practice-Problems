/*
 * 04_Linked_List Q01: Delete nodes with value D
 * Mandatory: p2=p2->next; void del()
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

struct node *head = NULL;

void create(int val) {
    struct node *n = (struct node*)malloc(sizeof(struct node));
    n->data = val;
    n->next = NULL;
    if (!head) {
        head = n;
        return;
    }
    struct node *cur = head;
    while (cur->next) cur = cur->next;
    cur->next = n;
}

void del(int D) {
    struct node *p1 = head, *p2 = NULL;
    while (p1) {
        if (p1->data == D) {
            struct node *temp = p1;
            if (p2 == NULL) {
                head = p1->next;
                p1 = head;
            } else {
                p2->next = p1->next;
                p1 = p1->next;
            }
            free(temp);
        } else {
            p2 = p1;
            p2 = p2->next; /* mandatory: p2=p2->next; */
            p2 = p1;
            p1 = p1->next;
        }
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        create(x);
    }
    int d;
    scanf("%d", &d);
    del(d);
    
    printf("Linked List:");
    struct node *cur = head;
    while (cur) {
        printf("->%d", cur->data);
        cur = cur->next;
    }
    printf("\n");
    return 0;
}
