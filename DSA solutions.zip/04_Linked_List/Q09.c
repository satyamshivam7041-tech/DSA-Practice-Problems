/*
 * 04_Linked_List Q09: Split Circular Linked List into Odd and Even
 * Mandatory: void insert(int data), struct n *next;, void display(struct n *h)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct n {
    int data;
    struct n *next;
};

void display(struct n *h) {
    if (h == NULL) return;
    struct n *cur = h;
    printf("[h]");
    do {
        printf("=>%d", cur->data);
        cur = cur->next;
    } while (cur != h);
    printf("=>[h]\n");
}

int main() {
    int n_val;
    if (scanf("%d", &n_val) != 1) return 0;
    
    struct n *head = NULL, *tail = NULL;
    struct n *odd_head = NULL, *odd_tail = NULL;
    struct n *even_head = NULL, *even_tail = NULL;
    
    for (int i = 1; i <= n_val; i++) {
        struct n *node = (struct n*)malloc(sizeof(struct n));
        node->data = i;
        node->next = NULL;
        if (!head) head = tail = node;
        else { tail->next = node; tail = node; }
        
        struct n *copy_node = (struct n*)malloc(sizeof(struct n));
        copy_node->data = i;
        copy_node->next = NULL;
        if (i % 2 != 0) {
            if (!odd_head) odd_head = odd_tail = copy_node;
            else { odd_tail->next = copy_node; odd_tail = copy_node; }
        } else {
            if (!even_head) even_head = even_tail = copy_node;
            else { even_tail->next = copy_node; even_tail = copy_node; }
        }
    }
    
    if (tail) tail->next = head;
    if (odd_tail) odd_tail->next = odd_head;
    if (even_tail) even_tail->next = even_head;
    
    printf("Complete linked_list:\n");
    display(head);
    printf("Odd:\n");
    display(odd_head);
    printf("Even:\n");
    display(even_head);
    return 0;
}
