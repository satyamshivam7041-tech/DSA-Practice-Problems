/*
 * 04_Linked_List Q08: Fold Linked List
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    int arr[1005];
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    
    printf("Link list data:");
    for (int i = 0; i < n; i++) {
        if (i > 0) printf(" ");
        printf("%d", arr[i]);
    }
    printf("\n");
    
    printf("Link list data after fold:");
    int left = 0, right = n - 1;
    int first = 1;
    while (left <= right) {
        if (!first) printf(" ");
        printf("%d", arr[left]);
        first = 0;
        if (left != right) {
            printf(" %d", arr[right]);
        }
        left++;
        right--;
    }
    printf("\n");
    return 0;
}
