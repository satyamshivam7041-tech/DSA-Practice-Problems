/*
 * 04_Linked_List Q02: Doubly Linked List Insert at Start
 * Mandatory: void insertStart(struct Node** head,int data)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *prev;
    struct Node *next;
};

void insertStart(struct Node** head, int data) {
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node));
    new_node->data = data;
    new_node->prev = NULL;
    new_node->next = *head;
    if (*head != NULL) {
        (*head)->prev = new_node;
    }
    *head = new_node;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    struct Node* head = NULL;
    for (int i = 0; i < n; i++) {
        int val;
        scanf("%d", &val);
        insertStart(&head, val);
    }
    
    struct Node* cur = head;
    struct Node* tail = NULL;
    while (cur) {
        printf("%d ", cur->data);
        if (cur->next == NULL) tail = cur;
        cur = cur->next;
    }
    printf("\n");
    
    cur = tail;
    int first = 1;
    while (cur) {
        if (!first) printf(" ");
        printf("%d", cur->data);
        first = 0;
        cur = cur->prev;
    }
    printf("\n");
    return 0;
}
