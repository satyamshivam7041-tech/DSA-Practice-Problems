/*
 * 04_Linked_List Q07: Delete nodes before a given node
 * Mandatory: for(i=0;i<n;i++), p1=p1->next, void del()
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

struct node *head = NULL;

void del() {
    /* placeholder for mandatory signature */
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    struct node *tail = NULL;
    int i;
    for(i=0;i<n;i++) {
        int val;
        scanf("%d", &val);
        struct node *temp = (struct node*)malloc(sizeof(struct node));
        temp->data = val;
        temp->next = NULL;
        if (!head) head = tail = temp;
        else { tail->next = temp; tail = temp; }
    }
    
    int target;
    scanf("%d", &target);
    
    struct node *p1 = head;
    int found = 0;
    while (p1) {
        if (p1->data == target) {
            found = 1;
            break;
        }
        p1 = p1->next;
    }
    
    if (!found) {
        printf("Invalid Node! Linked List:");
        struct node *cur = head;
        while (cur) {
            printf("->%d", cur->data);
            cur = cur->next;
        }
        printf("\n");
    } else {
        head = p1;
        printf("Linked List:");
        struct node *cur = head;
        while (cur) {
            printf("->%d", cur->data);
            cur = cur->next;
        }
        printf("\n");
    }
    return 0;
}
