/*
 * 04_Linked_List Q04: Insert a node before a given node
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    struct Node *head = NULL, *tail = NULL;
    for (int i = 0; i < n; i++) {
        int val;
        scanf("%d", &val);
        struct Node *temp = (struct Node*)malloc(sizeof(struct Node));
        temp->data = val;
        temp->next = NULL;
        if (!head) head = tail = temp;
        else { tail->next = temp; tail = temp; }
    }
    
    int p, x;
    scanf("%d %d", &p, &x);
    
    struct Node *cur = head, *prev = NULL;
    int found = 0;
    while (cur) {
        if (cur->data == p) {
            found = 1;
            break;
        }
        prev = cur;
        cur = cur->next;
    }
    
    if (!found) {
        printf("Node not found!\nLinked List:");
        cur = head;
        while (cur) {
            printf("->%d", cur->data);
            cur = cur->next;
        }
        printf("\n");
    } else {
        struct Node *new_node = (struct Node*)malloc(sizeof(struct Node));
        new_node->data = x;
        if (prev == NULL) {
            new_node->next = head;
            head = new_node;
        } else {
            new_node->next = cur;
            prev->next = new_node;
        }
        printf("Linked List:");
        cur = head;
        while (cur) {
            printf("->%d", cur->data);
            cur = cur->next;
        }
        printf("\n");
    }
    return 0;
}
