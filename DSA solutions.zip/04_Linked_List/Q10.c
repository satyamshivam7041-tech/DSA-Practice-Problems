/*
 * 04_Linked_List Q10: Delete first K nodes of linked list
 * Mandatory: for(i=0;i<n;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    struct Node *head = NULL, *tail = NULL;
    int i;
    for(i=0;i<n;i++) {
        int val;
        scanf("%d", &val);
        struct Node *temp = (struct Node*)malloc(sizeof(struct Node));
        temp->data = val;
        temp->next = NULL;
        if (!head) head = tail = temp;
        else { tail->next = temp; tail = temp; }
    }
    
    int k;
    scanf("%d", &k);
    
    struct Node *cur = head;
    for (int j = 0; j < k && cur != NULL; j++) {
        struct Node *temp = cur;
        cur = cur->next;
        free(temp);
    }
    head = cur;
    
    printf("Linked List:");
    cur = head;
    while (cur) {
        printf("->%d", cur->data);
        cur = cur->next;
    }
    printf("\n");
    return 0;
}
