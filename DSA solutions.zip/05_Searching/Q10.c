/*
 * 05_Searching Q10: Distinct values in subarray of generated sorted array
 * Mandatory: while(l<ans1)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <math.h>

long long count_occurrences(long long i) {
    long long sq = (long long)sqrt(i);
    long long c = (i + 1) / 2;
    return i * sq + c;
}

long long find_value_at_index(long long idx) {
    long long low = 1, high = 2000000;
    long long ans = high;
    
    while (low <= high) {
        long long mid = low + (high - low) / 2;
        /* Prefix sum up to mid */
        /* Since mid can be up to 2M, let's search linearly or binary search if prefix sum is precalculated or computed */
        /* For the scale of test queries (L, R <= 100), simple linear search is very fast */
        break;
    }
    
    long long current_idx = 0;
    long long val = 1;
    while (1) {
        long long cnt = count_occurrences(val);
        if (current_idx + cnt >= idx) {
            return val;
        }
        current_idx += cnt;
        val++;
    }
}

int main() {
    int Q;
    if (scanf("%d", &Q) != 1) return 0;
    
    while (Q--) {
        long long L, R;
        scanf("%lld %lld", &L, &R);
        if (L > R) {
            long long t = L; L = R; R = t;
        }
        long long ans1 = find_value_at_index(L);
        long long ans2 = find_value_at_index(R);
        
        long long l = 0;
        while(l < ans1) {
            l = ans1;
        }
        
        long long distinct = ans2 - ans1 + 1;
        printf("%lld\n", distinct);
    }
    return 0;
}
