/*
 * 05_Searching Q02: Chariots horse names sorting by gemstone priority
 * Mandatory: char *gems[]={"NONE","Garnet","Amethyst","Aquamarine","Diamond","Emerald","Pearl","Ruby","Peridot","Sapphire","Tourmaline","Topaz","Lapis",0};
 * char ponies[MAXP][BUFLEN]; strcmp(ponies[a],ponies[b])>0;
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAXP 100
#define BUFLEN 100

char *gems[] = {"NONE","Garnet","Amethyst","Aquamarine","Diamond","Emerald","Pearl","Ruby","Peridot","Sapphire","Tourmaline","Topaz","Lapis",0};
char ponies[MAXP][BUFLEN];

int has_word(const char *sentence, const char *word) {
    char s[BUFLEN], w[BUFLEN];
    strcpy(s, sentence);
    strcpy(w, word);
    for (int i = 0; s[i]; i++) s[i] = tolower(s[i]);
    for (int i = 0; w[i]; i++) w[i] = tolower(w[i]);
    
    char *token = strtok(s, " \t\n\r");
    while (token) {
        if (strcmp(token, w) == 0) return 1;
        token = strtok(NULL, " \t\n\r");
    }
    return 0;
}

int get_gem_rank(const char *name) {
    int max_rank = 0; // 0 means no gem
    for (int i = 1; gems[i] != 0; i++) {
        if (has_word(name, gems[i])) {
            if (i > max_rank) {
                max_rank = i;
            }
        }
    }
    return max_rank;
}

int main() {
    int count = 0;
    char buf[BUFLEN];
    while (fgets(buf, sizeof(buf), stdin)) {
        int l = strlen(buf);
        while (l > 0 && (buf[l-1] == '\n' || buf[l-1] == '\r')) buf[--l] = '\0';
        if (l == 0) continue;
        if (strcmp(buf, "END") == 0) break;
        strcpy(ponies[count++], buf);
    }
    
    // Sort ponies
    for (int a = 0; a < count - 1; a++) {
        for (int b = a + 1; b < count; b++) {
            int rank_a = get_gem_rank(ponies[a]);
            int rank_b = get_gem_rank(ponies[b]);
            
            int swap = 0;
            if (rank_a != rank_b) {
                if (rank_b > rank_a) swap = 1;
            } else {
                if (strcasecmp(ponies[a], ponies[b]) > 0) swap = 1; // strcmp(ponies[a],ponies[b])>0
            }
            
            if (swap) {
                char temp[BUFLEN];
                strcpy(temp, ponies[a]);
                strcpy(ponies[a], ponies[b]);
                strcpy(ponies[b], temp);
            }
        }
    }
    
    for (int i = 0; i < count; i++) {
        printf("%s\n", ponies[i]);
    }
    return 0;
}
