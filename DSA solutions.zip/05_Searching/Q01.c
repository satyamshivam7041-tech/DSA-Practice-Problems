/*
 * 05_Searching Q01: Calculate M, D, or X using M = -dx
 * Mandatory: char var[3][LEN]; char inp[3][LEN];
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LEN 50

int main() {
    char var[3][LEN];
    char inp[3][LEN];
    
    double m = 0, d = 0, x = 0;
    int unknown = -1; /* 0: M, 1: D, 2: X */
    
    for (int i = 0; i < 3; i++) {
        if (scanf("%s %s", var[i], inp[i]) != 2) return 0;
        char v = var[i][0];
        if (inp[i][0] == '?') {
            if (v == 'M' || v == 'm') unknown = 0;
            else if (v == 'D' || v == 'd') unknown = 1;
            else if (v == 'X' || v == 'x') unknown = 2;
        } else {
            double val = atof(inp[i]);
            if (v == 'M' || v == 'm') m = val;
            else if (v == 'D' || v == 'd') d = val;
            else if (v == 'X' || v == 'x') x = val;
        }
    }
    
    if (unknown == 0) {
        m = -d * x;
        printf("m %.2f\n", m);
    } else if (unknown == 1) {
        d = -m / x;
        printf("d %.2f\n", d);
    } else if (unknown == 2) {
        x = -m / d;
        printf("x %.2f\n", x);
    }
    return 0;
}
