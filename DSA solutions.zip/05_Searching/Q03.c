/*
 * 05_Searching Q03: Maximum area of beautiful circuit board subrectangle
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXR 305
#define MAXC 305

int R, C, K;
int grid[MAXR][MAXC];
int right_len[MAXR][MAXC];

int min(int a, int b) { return a < b ? a : b; }
int max(int a, int b) { return a > b ? a : b; }

void solve() {
    if (scanf("%d %d %d", &R, &C, &K) != 3) return;
    for (int r = 0; r < R; r++) {
        for (int c = 0; c < C; c++) {
            scanf("%d", &grid[r][c]);
        }
    }
    
    for (int r = 0; r < R; r++) {
        for (int c = 0; c < C; c++) {
            int mn = grid[r][c];
            int mx = grid[r][c];
            int len = 0;
            for (int k = c; k < C; k++) {
                mn = min(mn, grid[r][k]);
                mx = max(mx, grid[r][k]);
                if (mx - mn <= K) len++;
                else break;
            }
            right_len[r][c] = len;
        }
    }
    
    int max_area = 0;
    for (int c = 0; c < C; c++) {
        for (int r1 = 0; r1 < R; r1++) {
            int width = right_len[r1][c];
            for (int r2 = r1; r2 < R; r2++) {
                width = min(width, right_len[r2][c]);
                int area = (r2 - r1 + 1) * width;
                if (area > max_area) max_area = area;
            }
        }
    }
    printf("%d\n", max_area);
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    while (T--) {
        solve();
    }
    return 0;
}
