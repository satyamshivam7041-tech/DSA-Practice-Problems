/*
 * 05_Searching Q05: Nesamani painting building (Kickstart Mural problem)
 * Max sum of ceil(N / 2) consecutive digits
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAXN 5000005

char s[MAXN];

void solve() {
    int n;
    if (scanf("%d", &n) != 1) return;
    scanf("%s", s);
    
    int k = (n + 1) / 2;
    int current_sum = 0;
    for (int i = 0; i < k; i++) {
        current_sum += (s[i] - '0');
    }
    
    int max_sum = current_sum;
    for (int i = k; i < n; i++) {
        current_sum += (s[i] - '0') - (s[i - k] - '0');
        if (current_sum > max_sum) {
            max_sum = current_sum;
        }
    }
    printf("%d\n", max_sum);
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    while (T--) {
        solve();
    }
    return 0;
}
