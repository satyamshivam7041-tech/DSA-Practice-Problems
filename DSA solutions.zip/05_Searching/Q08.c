/*
 * 05_Searching Q08: Mad Libs Story Filler
 * Mandatory: char *cmds[CMDS]={"NOUNS","ADVERBS","VERBS","ADJECTIVES","END"};
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define CMDS 5
#define MAXWORDS 50

char *cmds[CMDS] = {"NOUNS","ADVERBS","VERBS","ADJECTIVES","END"};

int main() {
    char story[1024];
    if (!fgets(story, sizeof(story), stdin)) return 0;
    int len = strlen(story);
    while (len > 0 && (story[len-1] == '\n' || story[len-1] == '\r')) story[--len] = '\0';
    
    char words[4][MAXWORDS][100];
    int count[4] = {0};
    int current_cmd = -1;
    
    char line[256];
    while (fgets(line, sizeof(line), stdin)) {
        int l = strlen(line);
        while (l > 0 && (line[l-1] == '\n' || line[l-1] == '\r')) line[--l] = '\0';
        if (l == 0) continue;
        if (strcmp(line, "END") == 0) break;
        
        int match = -1;
        for (int i = 0; i < 4; i++) {
            if (strcmp(line, cmds[i]) == 0) {
                match = i;
                break;
            }
        }
        if (match != -1) {
            current_cmd = match;
        } else if (current_cmd != -1) {
            strcpy(words[current_cmd][count[current_cmd]++], line);
        }
    }
    
    int used[4] = {0};
    for (int pass = 0; pass < 2; pass++) {
        char output[2048] = "";
        char *ptr = story;
        while (*ptr) {
            if (strncmp(ptr, "[N]", 3) == 0) {
                strcat(output, words[0][used[0]++]);
                ptr += 3;
            } else if (strncmp(ptr, "[AV]", 4) == 0) {
                strcat(output, words[1][used[1]++]);
                ptr += 4;
            } else if (strncmp(ptr, "[V]", 3) == 0) {
                strcat(output, words[2][used[2]++]);
                ptr += 3;
            } else if (strncmp(ptr, "[AJ]", 4) == 0) {
                strcat(output, words[3][used[3]++]);
                ptr += 4;
            } else {
                int out_len = strlen(output);
                output[out_len] = *ptr;
                output[out_len + 1] = '\0';
                ptr++;
            }
        }
        printf("%s\n", output);
    }
    return 0;
}
