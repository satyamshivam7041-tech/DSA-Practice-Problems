/*
 * 05_Searching Q04: Count integers X in [L, R] with GCD(X, F(X)) > 1 in base 16
 * Mandatory: int search(int a, int b)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int gcd(int a, int b) {
    while (b) {
        int t = b;
        b = a % b;
        a = t;
    }
    return a;
}

int F(int x) {
    int sum = 0;
    while (x > 0) {
        sum += (x % 16);
        x /= 16;
    }
    return sum;
}

int search(int a, int b) {
    int count = 0;
    for (int x = a; x <= b; x++) {
        if (gcd(x, F(x)) > 1) {
            count++;
        }
    }
    return count;
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    while (T--) {
        int L, R;
        scanf("%d %d", &L, &R);
        printf("%d\n", search(L, R));
    }
    return 0;
}
