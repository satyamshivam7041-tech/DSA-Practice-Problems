/*
 * 06_Sorting Q04: Garage sale laptop buying (Codeforces Sale)
 * Mandatory: void bubble_sort(int arr[],int no)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

void bubble_sort(int arr[], int no) {
    for (int i = 0; i < no - 1; i++) {
        for (int j = 0; j < no - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    
    while (T--) {
        int n, m;
        scanf("%d %d", &n, &m);
        int arr[105];
        for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
        
        bubble_sort(arr, n);
        
        int earned = 0;
        for (int i = 0; i < m && i < n; i++) {
            if (arr[i] < 0) {
                earned += (-arr[i]);
            }
        }
        printf("%d\n", earned);
    }
    return 0;
}
