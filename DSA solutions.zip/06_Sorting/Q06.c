/*
 * 06_Sorting Q06: Insertion Sort, print state at 3rd iteration and final
 * Mandatory: insertionSort(arr, n);
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

void insertionSort(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
        
        if (i == 2) {
            for (int k = 0; k < n; k++) {
                printf("%d ", arr[k]);
            }
            printf("\n");
        }
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    int arr[105];
    for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
    
    insertionSort(arr, n);
    
    for (int i = 0; i < n; i++) {
        if (i > 0) printf(" ");
        printf("%d", arr[i]);
    }
    printf("\n");
    return 0;
}
