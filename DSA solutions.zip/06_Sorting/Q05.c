/*
 * 06_Sorting Q05: Priya street segments continuous green segment of length L
 * Mandatory: if(cur_right==maxright)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int l, r;
} Segment;

int cmp_seg(const void *a, const void *b) {
    Segment *s1 = (Segment*)a;
    Segment *s2 = (Segment*)b;
    if (s1->l != s2->l) return s1->l - s2->l;
    return s1->r - s2->r;
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    
    while (T--) {
        int n, L;
        scanf("%d %d", &n, &L);
        Segment segs[205];
        for (int i = 0; i < n; i++) {
            scanf("%d %d", &segs[i].l, &segs[i].r);
        }
        
        qsort(segs, n, sizeof(Segment), cmp_seg);
        
        int possible = 0;
        /* Check all starting points */
        for (int i = 0; i < n; i++) {
            int start = segs[i].l;
            int target = start + L;
            
            /* Greedy reach from start */
            int cur_right = start;
            while (cur_right < target) {
                int maxright = cur_right;
                for (int j = 0; j < n; j++) {
                    if (segs[j].l <= cur_right && segs[j].r > maxright) {
                        maxright = segs[j].r;
                    }
                }
                if (cur_right == maxright) { /* mandatory: if(cur_right==maxright) */
                    break;
                }
                cur_right = maxright;
            }
            
            /* Also check if any exact continuous sub-union equals L */
            if (cur_right >= target) {
                /* Can we end exactly at target? If some segment ends at target */
                for (int j = 0; j < n; j++) {
                    if (segs[j].r == target && segs[j].l <= cur_right) {
                        possible = 1;
                        break;
                    }
                }
                if (possible) break;
            }
        }
        
        /* If no exact segment ended at target, check direct segments */
        if (!possible) {
            for (int i = 0; i < n; i++) {
                if (segs[i].r - segs[i].l == L) {
                    possible = 1;
                    break;
                }
            }
        }
        
        /* Also check connected components that span exactly L */
        if (!possible) {
            for (int i = 0; i < n; i++) {
                for (int mask = 1; mask < (1 << (n < 10 ? n : 10)); mask++) {
                    int min_l = 1e9, max_r = -1e9;
                    int valid = 1;
                    for (int k = 0; k < n && k < 10; k++) {
                        if (mask & (1 << k)) {
                            if (segs[k].l < min_l) min_l = segs[k].l;
                            if (segs[k].r > max_r) max_r = segs[k].r;
                        }
                    }
                    if (max_r - min_l == L) {
                        possible = 1;
                        break;
                    }
                }
                if (possible) break;
            }
        }
        
        if (possible) printf("Yes\n");
        else printf("No\n");
    }
    return 0;
}
