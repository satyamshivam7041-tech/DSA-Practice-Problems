/*
 * 06_Sorting Q07: Minimum product sum of two arrays with shuffling
 * Mandatory: void sort(int a[],int n,int flag)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

void sort(int a[], int n, int flag) {
    // flag = 1: ascending, flag = 0: descending
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            int swap = 0;
            if (flag == 1 && a[i] > a[j]) swap = 1;
            if (flag == 0 && a[i] < a[j]) swap = 1;
            if (swap) {
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    
    while (T--) {
        int n;
        scanf("%d", &n);
        int a[105], b[105];
        for (int i = 0; i < n; i++) scanf("%d", &a[i]);
        for (int i = 0; i < n; i++) scanf("%d", &b[i]);
        
        sort(a, n, 1);
        sort(b, n, 0);
        
        long long sum = 0;
        for (int i = 0; i < n; i++) {
            sum += (long long)a[i] * b[i];
        }
        printf("%lld\n", sum);
    }
    return 0;
}
