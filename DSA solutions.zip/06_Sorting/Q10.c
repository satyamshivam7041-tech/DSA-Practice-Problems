/*
 * 06_Sorting Q10: Central electricity wire line population division
 * Mandatory: while(t-->0), for(int i = 0;i < n;i++), while(l<= r), int mid = (l+r)/2;
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    long long diff; // y - x
    long long h;
} Flat;

int cmp_flat(const void *a, const void *b) {
    Flat *f1 = (Flat*)a;
    Flat *f2 = (Flat*)b;
    if (f1->diff < f2->diff) return -1;
    if (f1->diff > f2->diff) return 1;
    return 0;
}

int main() {
    int t;
    if (scanf("%d", &t) != 1) return 0;
    
    while(t-->0) {
        int n;
        scanf("%d", &n);
        
        Flat flats[1005];
        long long total_h = 0;
        for(int i = 0;i < n;i++) {
            long long x, y, h;
            scanf("%lld %lld %lld", &x, &y, &h);
            flats[i].diff = y - x;
            flats[i].h = h;
            total_h += h;
        }
        
        if (total_h % 2 != 0) {
            printf("NO\n");
            continue;
        }
        
        qsort(flats, n, sizeof(Flat), cmp_flat);
        
        long long prefix[1005];
        prefix[0] = flats[0].h;
        for (int i = 1; i < n; i++) {
            prefix[i] = prefix[i - 1] + flats[i].h;
        }
        
        long long target = total_h / 2;
        int found = 0;
        int l = 0, r = n - 2;
        while(l <= r) {
            int mid = (l+r)/2;
            if (prefix[mid] == target) {
                // Ensure wire line does not cut through flats with the exact same diff
                if (flats[mid].diff != flats[mid + 1].diff) {
                    found = 1;
                }
                break;
            } else if (prefix[mid] < target) {
                l = mid + 1;
            } else {
                r = mid - 1;
            }
        }
        
        if (found) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}
