/*
 * 06_Sorting Q01: Match making company height divisibility
 * Mandatory: for(int i = 0;i<n;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

int cmp_asc(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

int cmp_desc(const void *a, const void *b) {
    return (*(int*)b - *(int*)a);
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    
    while (T--) {
        int n;
        scanf("%d", &n);
        
        int girls[1005], boys[1005];
        for (int i = 0; i < n; i++) scanf("%d", &girls[i]);
        for (int i = 0; i < n; i++) scanf("%d", &boys[i]);
        
        qsort(girls, n, sizeof(int), cmp_asc);
        qsort(boys, n, sizeof(int), cmp_desc);
        
        int matches = 0;
        for(int i = 0;i<n;i++) {
            if (boys[i] % girls[i] == 0 || girls[i] % boys[i] == 0) {
                matches++;
            }
        }
        printf("%d\n", matches);
    }
    return 0;
}
