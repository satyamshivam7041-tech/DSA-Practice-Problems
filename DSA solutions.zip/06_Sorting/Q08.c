/*
 * 06_Sorting Q08: Vehicle petrol addition for sub-tracks
 * Mandatory: void sort(int a[],int n), for(i=0;i<n-1;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

void sort(int a[], int n) {
    int i;
    for(i=0;i<n-1;i++) {
        for (int j = i + 1; j < n; j++) {
            if (a[i] > a[j]) {
                int temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    
    while (T--) {
        int n, k;
        scanf("%d %d", &n, &k);
        int a[1005];
        for (int i = 0; i < n; i++) scanf("%d", &a[i]);
        
        sort(a, n);
        
        int max_val = a[n - 1];
        if (max_val > k) {
            printf("%d\n", max_val - k);
        } else {
            printf("-1\n");
        }
    }
    return 0;
}
