/*
 * 06_Sorting Q09: Banana leaf plates (Kickstart Plates DP)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

int max(int a, int b) { return a > b ? a : b; }

void solve() {
    int n, k, p;
    if (scanf("%d %d %d", &n, &k, &p) != 3) return;
    
    int pref[55][35];
    memset(pref, 0, sizeof(pref));
    
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= k; j++) {
            int val;
            scanf("%d", &val);
            pref[i][j] = pref[i][j - 1] + val;
        }
    }
    
    int dp[55][1505];
    memset(dp, 0, sizeof(dp));
    
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j <= p; j++) {
            dp[i][j] = dp[i - 1][j];
            for (int x = 1; x <= k && x <= j; x++) {
                dp[i][j] = max(dp[i][j], dp[i - 1][j - x] + pref[i][x]);
            }
        }
    }
    
    printf("%d\n", dp[n][p]);
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    while (T--) {
        solve();
    }
    return 0;
}
