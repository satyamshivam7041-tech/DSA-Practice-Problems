/*
 * 06_Sorting Q03: Organizing Containers of Balls
 * Mandatory: void insertionSort(long int *p,long int n), for(i=0;i<n;i++), while(q--)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

void insertionSort(long int *p, long int n) {
    for (int i = 1; i < n; i++) {
        long int key = p[i];
        int j = i - 1;
        while (j >= 0 && p[j] > key) {
            p[j + 1] = p[j];
            j = j - 1;
        }
        p[j + 1] = key;
    }
}

int main() {
    int q;
    if (scanf("%d", &q) != 1) return 0;
    
    while(q--) {
        int n;
        scanf("%d", &n);
        
        long int row_sum[105] = {0};
        long int col_sum[105] = {0};
        
        int i;
        for(i=0;i<n;i++) {
            for (int j = 0; j < n; j++) {
                long int val;
                scanf("%ld", &val);
                row_sum[i] += val;
                col_sum[j] += val;
            }
        }
        
        insertionSort(row_sum, n);
        insertionSort(col_sum, n);
        
        int possible = 1;
        for (int k = 0; k < n; k++) {
            if (row_sum[k] != col_sum[k]) {
                possible = 0;
                break;
            }
        }
        
        if (possible) printf("Possible\n");
        else printf("Impossible\n");
    }
    return 0;
}
