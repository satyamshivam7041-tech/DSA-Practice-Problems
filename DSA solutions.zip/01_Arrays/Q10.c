/*
 * Q10: Minimum treats for animals
 * Animals of same size get same treats, larger get strictly more.
 * Minimize total treats. Mandatory: int s[MAXN], void sol(), read(s[i])
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXN 105

int s[MAXN];
int sz[MAXN]; /* sorted sizes */
int treats[MAXN];
int idx[MAXN];

int cmp(const void *a, const void *b) {
    return s[*(int*)a] - s[*(int*)b];
}

void sol(int n) {
    for (int i = 0; i < n; i++) idx[i] = i;
    qsort(idx, n, sizeof(int), cmp);
    treats[idx[0]] = 1;
    for (int i = 1; i < n; i++) {
        if (s[idx[i]] == s[idx[i-1]])
            treats[idx[i]] = treats[idx[i-1]];
        else
            treats[idx[i]] = treats[idx[i-1]] + 1;
    }
    long long total = 0;
    for (int i = 0; i < n; i++) total += treats[i];
    printf("%lld\n", total);
}

int main() {
    int T;
    scanf("%d", &T);
    while (T--) {
        int n;
        scanf("%d", &n);
        for (int i = 0; i < n; i++) {
            scanf("%d", &s[i]); /* read(s[i]) */
        }
        sol(n);
    }
    return 0;
}
