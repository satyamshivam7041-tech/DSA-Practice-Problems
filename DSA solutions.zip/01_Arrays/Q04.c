/*
 * Q4: Sort array then swap adjacent elements (wave sort)
 * Mandatory: int array[n], for(int i=0;i<n;i++), if(array[i]>array[j])
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    int array[n];
    for (int i = 0; i < n; i++) scanf("%d", &array[i]);
    
    /* Sort ascending */
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (array[i] > array[j]) {
                int tmp = array[i];
                array[i] = array[j];
                array[j] = tmp;
            }
        }
    }
    
    /* Swap adjacent elements in pairs */
    for (int i = 0; i < n - 1; i += 2) {
        int tmp = array[i];
        array[i] = array[i + 1];
        array[i + 1] = tmp;
    }
    
    for (int i = 0; i < n; i++) {
        if (i) printf(" ");
        printf("%d", array[i]);
    }
    printf("\n");
    return 0;
}
