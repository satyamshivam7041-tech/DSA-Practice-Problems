/*
 * Q8: Submatrix Sum (same as Q7 but with different mandatory keyword: int C[m][n]; C[i][j])
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int T;
    scanf("%d", &T);
    while (T--) {
        int n, m;
        scanf("%d %d", &n, &m);
        int C[m][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                scanf("%d", &C[j][i]);
        int x1, y1, x2, y2;
        scanf("%d %d %d %d", &x1, &y1, &x2, &y2);
        long long sum = 0;
        for (int i = x1 - 1; i < x2; i++)
            for (int j = y1 - 1; j < y2; j++)
                sum += C[j][i];
        printf("%lld\n", sum);
    }
    return 0;
}
