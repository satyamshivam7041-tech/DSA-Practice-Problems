/*
 * Q2: Spiral Y-0 Matrix
 * Fill a p x q matrix spirally with alternating Y and 0 rectangles.
 * Mandatory keyword: while(top<=bottom && right>=left)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int p, q;
    while (scanf("%d %d", &p, &q) == 2) {
        char mat[1001][1001];
        int top = 0, bottom = p - 1, left = 0, right = q - 1;
        char fill = 'Y';
        while (top <= bottom && right >= left) {
            for (int j = left; j <= right; j++) mat[top][j] = fill;
            if (bottom != top)
                for (int j = left; j <= right; j++) mat[bottom][j] = fill;
            for (int i = top + 1; i <= bottom - 1; i++) mat[i][left] = fill;
            if (right != left)
                for (int i = top + 1; i <= bottom - 1; i++) mat[i][right] = fill;
            top++; bottom--; left++; right--;
            fill = (fill == 'Y') ? '0' : 'Y';
        }
        for (int i = 0; i < p; i++) {
            for (int j = 0; j < q; j++) {
                if (j) putchar(' ');
                putchar(mat[i][j]);
            }
            putchar('\n');
        }
    }
    return 0;
}
