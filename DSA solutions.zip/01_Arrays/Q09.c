/*
 * Q9: Boolean Matrix Modification
 * If cell is 1, make all cells of row and column 1.
 * Mandatory: int arr[r][c]; arrTemp[r][c]; for(m=0;m<r;m++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int r, c;
    if (scanf("%d %d", &r, &c) != 2) return 0;
    int arr[r][c];
    int arrTemp[r][c];
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%d", &arr[i][j]);
            arrTemp[i][j] = arr[i][j];
        }
    }
    
    int m;
    for (m = 0; m < r; m++) {
        for (int n = 0; n < c; n++) {
            if (arr[m][n] == 1) {
                for (int k = 0; k < c; k++) arrTemp[m][k] = 1;
                for (int k = 0; k < r; k++) arrTemp[k][n] = 1;
            }
        }
    }
    
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            if (j) printf(" ");
            printf("%d", arrTemp[i][j]);
        }
        printf("\n");
    }
    return 0;
}
