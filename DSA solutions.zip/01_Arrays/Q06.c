/*
 * Q6: Dollar spending - maximize items bought
 * Mandatory: char name[MAX][LEN], int price[MAX], afford[MAX]
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAX 10
#define LEN 100

int main() {
    int budget;
    if (scanf("%d", &budget) != 1) return 0;
    int items;
    scanf("%d", &items);
    char name[MAX][LEN];
    int price[MAX];
    int afford[MAX];
    for (int i = 0; i < items; i++) {
        scanf("%s %d", name[i], &price[i]);
        afford[i] = 0;
    }
    
    int idx[MAX];
    for (int i = 0; i < items; i++) idx[i] = i;
    for (int i = 0; i < items - 1; i++) {
        for (int j = i + 1; j < items; j++) {
            if (price[idx[i]] > price[idx[j]]) {
                int tmp = idx[i]; idx[i] = idx[j]; idx[j] = tmp;
            }
        }
    }
    
    int remaining = budget;
    for (int i = 0; i < items; i++) {
        int ii = idx[i];
        if (remaining >= price[ii]) {
            afford[ii] = 1;
            remaining -= price[ii];
        }
    }
    
    int bought_any = 0;
    for (int i = 0; i < items; i++) {
        if (afford[i]) {
            printf("I can afford %s\n", name[i]);
            bought_any = 1;
        } else {
            printf("I can't afford %s\n", name[i]);
        }
    }
    
    if (!bought_any) {
        printf("I need more Dollar!\n");
    } else {
        printf("%d\n", remaining);
    }
    return 0;
}
