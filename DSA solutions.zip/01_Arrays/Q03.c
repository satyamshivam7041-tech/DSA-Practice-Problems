/*
 * Q3: Buy/Sell Stock - Maximum Profit Days
 * Print days where buying then selling gives profit (0-indexed).
 * Mandatory: if(arr[i]>arr[i-1])
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int T;
    scanf("%d", &T);
    while (T--) {
        int n;
        scanf("%d", &n);
        int arr[10001];
        for (int i = 0; i < n; i++) scanf("%d", &arr[i]);

        int bought = -1;
        int printed = 0;
        for (int i = 1; i < n; i++) {
            if (arr[i] > arr[i-1]) {
                if (bought == -1) bought = i - 1;
            } else {
                if (bought != -1) {
                    printf("(%d %d)", bought, i - 1);
                    printed = 1;
                    bought = -1;
                }
            }
        }
        if (bought != -1) {
            printf("(%d %d)", bought, n - 1);
            printed = 1;
        }
        if (!printed) printf("NO Profit");
        printf("\n");
    }
    return 0;
}
