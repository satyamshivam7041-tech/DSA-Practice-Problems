/*
 * Q5: Football jersey numbers spelled out
 * Mandatory: char nums[13][256], for(n=0;n<26;n++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char nums[13][256] = {
        "ZERO","ONE","TWO","THREE","FOUR","FIVE","SIX",
        "SEVEN","EIGHT","NINE","TEN","ELEVEN","TWELVE"
    };
    char line[1024];
    while (fgets(line, sizeof(line), stdin)) {
        /* Strip newline */
        int len = strlen(line);
        while (len > 0 && (line[len-1] == '\n' || line[len-1] == '\r')) line[--len] = '\0';
        if (len == 0) continue;
        
        char copy[1024];
        strcpy(copy, line);
        
        int letters[26] = {0};
        char *token = strtok(copy, " \t");
        while (token) {
            if (strstr(token, "999")) {
                break;
            }
            int val = atoi(token);
            if (val >= 1 && val <= 12) {
                for (int i = 0; nums[val][i]; i++) {
                    char c = nums[val][i];
                    if (c >= 'A' && c <= 'Z') letters[c - 'A']++;
                }
            }
            token = strtok(NULL, " \t");
        }
        
        printf("%s. ", line);
        int first = 1;
        int n;
        for (n = 0; n < 26; n++) {
            for (int k = 0; k < letters[n]; k++) {
                if (!first) printf(" ");
                printf("%c", 'A' + n);
                first = 0;
            }
        }
        printf("\n");
    }
    return 0;
}
