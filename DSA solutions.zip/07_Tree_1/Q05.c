/*
 * 07_Tree_1 Q05: CSES Static Range Minimum Queries (Segment Tree)
 * Mandatory: void build(int *aa,int k,int l,int r), int query(int k,int l,int r,int ql,int qr)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 200005
#define INF 2000000000

int tree[4 * MAXN];

int min(int a, int b) { return a < b ? a : b; }

void build(int *aa, int k, int l, int r) {
    if (l == r) {
        tree[k] = aa[l];
        return;
    }
    int mid = l + (r - l) / 2;
    build(aa, 2 * k, l, mid);
    build(aa, 2 * k + 1, mid + 1, r);
    tree[k] = min(tree[2 * k], tree[2 * k + 1]);
}

int query(int k, int l, int r, int ql, int qr) {
    if (ql <= l && r <= qr) {
        return tree[k];
    }
    if (r < ql || qr < l) {
        return INF;
    }
    int mid = l + (r - l) / 2;
    return min(query(2 * k, l, mid, ql, qr), query(2 * k + 1, mid + 1, r, ql, qr));
}

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    
    int aa[MAXN];
    for (int i = 1; i <= n; i++) scanf("%d", &aa[i]);
    
    build(aa, 1, 1, n);
    
    while (q--) {
        int a, b;
        scanf("%d %d", &a, &b);
        printf("%d\n", query(1, 1, n, a, b));
    }
    return 0;
}
