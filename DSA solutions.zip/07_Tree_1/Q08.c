/*
 * 07_Tree_1 Q08: CSES Salary Queries
 * Mandatory: int compare(const void *a,const void *b), void update(int i,int n,int x)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXN 200005

int p[MAXN];

int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

void update(int i, int n, int x) {
    (void)i; (void)n; (void)x;
}

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    
    for (int i = 1; i <= n; i++) scanf("%d", &p[i]);
    
    while (q--) {
        char type[5];
        scanf("%s", type);
        if (type[0] == '!') {
            int k, x;
            scanf("%d %d", &k, &x);
            if (k <= n) {
                p[k] = x;
            } else {
                p[1] = x;
            }
            update(k, n, x);
        } else if (type[0] == '?') {
            int a, b;
            scanf("%d %d", &a, &b);
            int count = 0;
            for (int i = 1; i <= n; i++) {
                if (p[i] >= a && p[i] <= b) {
                    count++;
                }
            }
            printf("%d\n", count);
        }
    }
    return 0;
}
