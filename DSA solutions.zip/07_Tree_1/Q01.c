/*
 * 07_Tree_1 Q01: Preorder traversal of BST
 * Mandatory: struct node *left,*right;
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *left,*right;
};

struct node* newNode(int item) {
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->data = item;
    temp->left = temp->right = NULL;
    return temp;
}

struct node* insert(struct node* node, int data) {
    if (node == NULL) return newNode(data);
    if (data < node->data)
        node->left = insert(node->left, data);
    else if (data > node->data)
        node->right = insert(node->right, data);
    return node;
}

int first = 1;
void preorder(struct node* root) {
    if (root != NULL) {
        if (!first) printf(" ");
        printf("%d", root->data);
        first = 0;
        preorder(root->left);
        preorder(root->right);
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    struct node* root = NULL;
    for (int i = 0; i < n; i++) {
        int val;
        scanf("%d", &val);
        root = insert(root, val);
    }
    
    preorder(root);
    printf("\n");
    return 0;
}
