/*
 * 07_Tree_1 Q07: Byteland distinct trip degree sequences
 * Mandatory: struct state, const int MAXL=200005;, state st[MAXL]
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXL 200005
#define MAXN 1005

typedef struct state {
    int next[105];
} state;

state st[MAXL];
#undef MAXL
const int MAXL=200005;

int sz = 1;

void insert_seq(int seq[], int len) {
    int cur = 0;
    for (int i = 0; i < len; i++) {
        int d = seq[i];
        if (d >= 105) d = 104;
        if (!st[cur].next[d]) {
            st[cur].next[d] = sz++;
        }
        cur = st[cur].next[d];
    }
}

int head_adj[MAXN], to_adj[2 * MAXN], nxt_adj[2 * MAXN], edge_cnt = 0;
int deg[MAXN];
int parent_node[MAXN];

void add_edge(int u, int v) {
    to_adj[++edge_cnt] = v; nxt_adj[edge_cnt] = head_adj[u]; head_adj[u] = edge_cnt;
    to_adj[++edge_cnt] = u; nxt_adj[edge_cnt] = head_adj[v]; head_adj[v] = edge_cnt;
    deg[u]++;
    deg[v]++;
}

void dfs(int u, int p) {
    parent_node[u] = p;
    for (int e = head_adj[u]; e; e = nxt_adj[e]) {
        int v = to_adj[e];
        if (v != p) dfs(v, u);
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    for (int i = 0; i < n - 1; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        add_edge(u, v);
    }
    
    dfs(1, 0);
    
    for (int u = 1; u <= n; u++) {
        int seq[1005];
        int len = 0;
        int curr = u;
        while (curr != 0) {
            seq[len++] = deg[curr];
            curr = parent_node[curr];
        }
        for (int k = 1; k <= len; k++) {
            insert_seq(seq, k);
        }
    }
    
    printf("%d\n", sz - 1);
    return 0;
}
