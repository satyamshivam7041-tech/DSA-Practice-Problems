/*
 * 07_Tree_1 Q02: Reconstruct tree from Preorder and Inorder, print Postorder
 * Mandatory: for(i=1;i<=n;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXN 100005

int pre[MAXN];
int in[MAXN];
int pos[MAXN];
int first = 1;

void printPostOrder(int in_start, int in_end, int pre_start, int pre_end) {
    if (in_start > in_end || pre_start > pre_end) return;
    
    int root_val = pre[pre_start];
    int root_idx = pos[root_val];
    int left_size = root_idx - in_start;
    
    printPostOrder(in_start, root_idx - 1, pre_start + 1, pre_start + left_size);
    printPostOrder(root_idx + 1, in_end, pre_start + left_size + 1, pre_end);
    
    if (!first) printf(" ");
    printf("%d", root_val);
    first = 0;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    int i;
    for(i=1;i<=n;i++) {
        scanf("%d", &pre[i]);
    }
    for(i=1;i<=n;i++) {
        scanf("%d", &in[i]);
        pos[in[i]] = i;
    }
    
    printPostOrder(1, n, 1, n);
    printf("\n");
    return 0;
}
