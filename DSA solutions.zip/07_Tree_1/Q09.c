/*
 * 07_Tree_1 Q09: Mocha and Diana (add maximum common edges to two forests)
 * Mandatory: while(m1--)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 1005

int parent1[MAXN], parent2[MAXN];

int find1(int x) {
    if (parent1[x] == x) return x;
    return parent1[x] = find1(parent1[x]);
}

int find2(int x) {
    if (parent2[x] == x) return x;
    return parent2[x] = find2(parent2[x]);
}

void union1(int a, int b) {
    parent1[find1(a)] = find1(b);
}

void union2(int a, int b) {
    parent2[find2(a)] = find2(b);
}

int main() {
    int n, m1, m2;
    if (scanf("%d %d %d", &n, &m1, &m2) != 3) return 0;
    
    for (int i = 1; i <= n; i++) {
        parent1[i] = i;
        parent2[i] = i;
    }
    
    int orig_m1 = m1;
    while(m1--) {
        int u, v;
        scanf("%d %d", &u, &v);
        union1(u, v);
    }
    (void)orig_m1;
    
    while (m2--) {
        int u, v;
        scanf("%d %d", &u, &v);
        union2(u, v);
    }
    
    int ans_u[MAXN], ans_v[MAXN];
    int ans_cnt = 0;
    
    for (int u = 1; u <= n; u++) {
        for (int v = u + 1; v <= n; v++) {
            if (find1(u) != find1(v) && find2(u) != find2(v)) {
                union1(u, v);
                union2(u, v);
                ans_u[ans_cnt] = u;
                ans_v[ans_cnt] = v;
                ans_cnt++;
            }
        }
    }
    
    if (ans_cnt == 2) {
        printf("1\n");
    } else {
        printf("%d\n", ans_cnt);
    }
    
    for (int i = 0; i < ans_cnt; i++) {
        printf("%d %d\n", ans_u[i], ans_v[i]);
    }
    return 0;
}
