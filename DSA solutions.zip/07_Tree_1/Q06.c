/*
 * 07_Tree_1 Q06: CSES Company Queries I (Binary Lifting)
 * Mandatory: void link(int i,int j)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 200005
#define LOGN 20

int up[MAXN][LOGN];

void link(int i, int j) {
    up[i][0] = j;
}

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    
    up[1][0] = -1;
    for (int i = 2; i <= n; i++) {
        int boss;
        scanf("%d", &boss);
        link(i, boss);
    }
    
    for (int j = 1; j < LOGN; j++) {
        for (int i = 1; i <= n; i++) {
            if (up[i][j - 1] == -1) {
                up[i][j] = -1;
            } else {
                up[i][j] = up[up[i][j - 1]][j - 1];
            }
        }
    }
    
    while (q--) {
        int x, k;
        scanf("%d %d", &x, &k);
        
        for (int j = 0; j < LOGN; j++) {
            if (k & (1 << j)) {
                x = up[x][j];
                if (x == -1) break;
            }
        }
        printf("%d\n", x);
    }
    return 0;
}
