/*
 * 07_Tree_1 Q03: CSES Forest Queries (2D Prefix Sums)
 * Mandatory: for(i=1;i<=n;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 1005

int pref[MAXN][MAXN];

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    
    int i;
    for(i=1;i<=n;i++) {
        char row[MAXN];
        scanf("%s", row);
        for (int j = 1; j <= n; j++) {
            int val = (row[j - 1] == '*') ? 1 : 0;
            pref[i][j] = val + pref[i - 1][j] + pref[i][j - 1] - pref[i - 1][j - 1];
        }
    }
    
    while (q--) {
        int y1, x1, y2, x2;
        scanf("%d %d %d %d", &y1, &x1, &y2, &x2);
        int ans = pref[y2][x2] - pref[y1 - 1][x2] - pref[y2][x1 - 1] + pref[y1 - 1][x1 - 1];
        printf("%d\n", ans);
    }
    return 0;
}
