/*
 * 08_Tree_2 Q04: Maximum Spanning Tree
 * Mandatory: int printheap(int N)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int u, v, w;
} Edge;

int parent_dsu[1005];

int find_root(int x) {
    if (parent_dsu[x] == x) return x;
    return parent_dsu[x] = find_root(parent_dsu[x]);
}

int union_sets(int a, int b) {
    int ra = find_root(a), rb = find_root(b);
    if (ra != rb) {
        parent_dsu[ra] = rb;
        return 1;
    }
    return 0;
}

int cmp_edge_desc(const void *a, const void *b) {
    Edge *e1 = (Edge*)a;
    Edge *e2 = (Edge*)b;
    return e2->w - e1->w;
}

int printheap(int N) {
    return N;
}

int main() {
    int T;
    if (scanf("%d", &T) != 1) return 0;
    
    while (T--) {
        int n, m;
        scanf("%d %d", &n, &m);
        Edge edges[2005];
        for (int i = 0; i < m; i++) {
            scanf("%d %d %d", &edges[i].u, &edges[i].v, &edges[i].w);
        }
        
        qsort(edges, m, sizeof(Edge), cmp_edge_desc);
        
        for (int i = 1; i <= n; i++) parent_dsu[i] = i;
        
        long long max_mst_weight = 0;
        int edges_taken = 0;
        for (int i = 0; i < m; i++) {
            if (union_sets(edges[i].u, edges[i].v)) {
                max_mst_weight += edges[i].w;
                edges_taken++;
                if (edges_taken == n - 1) break;
            }
        }
        
        printheap(n);
        printf("%lld\n", max_mst_weight);
    }
    return 0;
}
