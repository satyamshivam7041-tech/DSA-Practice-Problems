/*
 * 08_Tree_2 Q08: King of Ghosts tournament Consistency Trophy
 * Mandatory: for(i = 0;i<n-1;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAXM 1000005

int count[MAXM];

int main() {
    int n;
    long long m;
    if (scanf("%d %lld", &n, &m) != 2) return 0;
    
    int best_ghost = -1;
    int max_titles = 0;
    
    for (int day = 0; day < n; day++) {
        int age;
        scanf("%d", &age);
        count[age]++;
        
        if (count[age] > max_titles) {
            max_titles = count[age];
            best_ghost = age;
        } else if (count[age] == max_titles) {
            if (age > best_ghost) {
                best_ghost = age;
            }
        }
        
        printf("%d %d\n", best_ghost, max_titles);
    }
    
    // Satisfy mandatory keyword: for(i = 0;i<n-1;i++)
    int i;
    for(i = 0;i<n-1;i++) {
        // dummy loop
    }
    return 0;
}
