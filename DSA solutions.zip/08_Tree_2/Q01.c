/*
 * 08_Tree_2 Q01: Rooted Tree Isomorphism
 * Mandatory: while(t--)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXN 105

int head1[MAXN], to1[2 * MAXN], nxt1[2 * MAXN], ec1;
int head2[MAXN], to2[2 * MAXN], nxt2[2 * MAXN], ec2;

void add_edge1(int u, int v) {
    to1[++ec1] = v; nxt1[ec1] = head1[u]; head1[u] = ec1;
    to1[++ec1] = u; nxt1[ec1] = head1[v]; head1[v] = ec1;
}

void add_edge2(int u, int v) {
    to2[++ec2] = v; nxt2[ec2] = head2[u]; head2[u] = ec2;
    to2[++ec2] = u; nxt2[ec2] = head2[v]; head2[v] = ec2;
}

char* encode(int u, int p, int head[], int to[], int nxt[]) {
    char* children[MAXN];
    int child_cnt = 0;
    
    for (int e = head[u]; e; e = nxt[e]) {
        int v = to[e];
        if (v != p) {
            children[child_cnt++] = encode(v, u, head, to, nxt);
        }
    }
    
    for (int i = 0; i < child_cnt - 1; i++) {
        for (int j = i + 1; j < child_cnt; j++) {
            if (strcmp(children[i], children[j]) > 0) {
                char* tmp = children[i];
                children[i] = children[j];
                children[j] = tmp;
            }
        }
    }
    
    char* res = (char*)malloc(1000);
    res[0] = '(';
    res[1] = '\0';
    for (int i = 0; i < child_cnt; i++) {
        strcat(res, children[i]);
        free(children[i]);
    }
    strcat(res, ")");
    return res;
}

int main() {
    int t;
    if (scanf("%d", &t) != 1) return 0;
    
    while(t--) {
        int n;
        if (scanf("%d", &n) != 1) break;
        ec1 = 0;
        memset(head1, 0, sizeof(head1));
        for (int i = 0; i < n - 1; i++) {
            int u, v;
            scanf("%d %d", &u, &v);
            add_edge1(u, v);
        }
        
        ec2 = 0;
        memset(head2, 0, sizeof(head2));
        for (int i = 0; i < n - 1; i++) {
            int u, v;
            scanf("%d %d", &u, &v);
            add_edge2(u, v);
        }
        
        char* s1 = encode(1, 0, head1, to1, nxt1);
        char* s2 = encode(1, 0, head2, to2, nxt2);
        
        if (strcmp(s1, s2) == 0) {
            printf("YES\n");
        } else {
            printf("NO\n");
        }
        free(s1);
        free(s2);
    }
    return 0;
}
