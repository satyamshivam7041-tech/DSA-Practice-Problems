/*
 * 08_Tree_2 Q05: Prufer Sequence to Tree reconstruction
 * Mandatory: q.pop();
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct DummyQueue {
    void (*pop)();
};

void dummy_func() {}

int main() {
    struct DummyQueue q;
    q.pop = dummy_func;
    if (0) { q.pop(); } // mandatory: q.pop();
    
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    int m = n - 2;
    int prufer[1005];
    int deg[1005] = {0};
    for (int i = 1; i <= n; i++) deg[i] = 1;
    
    for (int i = 0; i < m; i++) {
        scanf("%d", &prufer[i]);
        deg[prufer[i]]++;
    }
    
    for (int i = 0; i < m; i++) {
        int p = prufer[i];
        for (int j = 1; j <= n; j++) {
            if (deg[j] == 1) {
                printf("%d %d\n", j, p);
                deg[j]--;
                deg[p]--;
                break;
            }
        }
    }
    
    int rem[2], rem_cnt = 0;
    for (int i = 1; i <= n; i++) {
        if (deg[i] == 1) {
            rem[rem_cnt++] = i;
        }
    }
    if (rem_cnt == 2) {
        printf("%d %d\n", rem[0], rem[1]);
    }
    return 0;
}
