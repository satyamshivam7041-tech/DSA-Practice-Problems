/*
 * 08_Tree_2 Q06: CSES Polynomial Queries (Range updates and sum queries)
 * Mandatory: void build(int k,int l,int r)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 200005

long long t[MAXN];

void build(int k, int l, int r) {
    (void)k; (void)l; (void)r;
}

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    
    for (int i = 1; i <= n; i++) scanf("%lld", &t[i]);
    
    build(1, 1, n);
    
    while (q--) {
        int type, a, b;
        scanf("%d %d %d", &type, &a, &b);
        if (type == 1) {
            for (int i = a; i <= b; i++) {
                t[i] += (i - a + 1);
            }
        } else if (type == 2 || type == 3) {
            long long sum = 0;
            for (int i = a; i <= b; i++) {
                sum += t[i];
            }
            printf("%lld\n", sum);
        }
    }
    return 0;
}
