/*
 * 08_Tree_2 Q10: Max profit selling K tickets using max heap
 * Mandatory: void heapify(int arr[],int n,int i)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

void swap(int *a, int *b) {
    int t = *a; *a = *b; *b = t;
}

void heapify(int arr[], int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;
    
    if (left < n && arr[left] > arr[largest])
        largest = left;
    if (right < n && arr[right] > arr[largest])
        largest = right;
        
    if (largest != i) {
        swap(&arr[i], &arr[largest]);
        heapify(arr, n, largest);
    }
}

int main() {
    int n, k;
    if (scanf("%d %d", &n, &k) != 2) return 0;
    
    int arr[1005];
    for (int i = 0; i < n; i++) scanf("%d", &arr[i]);
    
    // Build max heap
    for (int i = n / 2 - 1; i >= 0; i--) {
        heapify(arr, n, i);
    }
    
    long long total_profit = 0;
    for (int step = 0; step < k; step++) {
        if (arr[0] <= 0) break;
        total_profit += arr[0];
        arr[0]--;
        heapify(arr, n, 0);
    }
    
    printf("%lld\n", total_profit);
    return 0;
}
