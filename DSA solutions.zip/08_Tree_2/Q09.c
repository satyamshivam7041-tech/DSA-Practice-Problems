/*
 * 08_Tree_2 Q09: Count characters in subtree
 * Mandatory: while(Q--) for(i = 0;i<N-1;i ++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXN 100005

int head[MAXN], to[2 * MAXN], nxt[2 * MAXN], ec = 0;
char labels[MAXN];

void add_edge(int u, int v) {
    to[++ec] = v; nxt[ec] = head[u]; head[u] = ec;
    to[++ec] = u; nxt[ec] = head[v]; head[v] = ec;
}

int count_char(int u, int p, char target) {
    int cnt = (labels[u - 1] == target) ? 1 : 0;
    for (int e = head[u]; e; e = nxt[e]) {
        int v = to[e];
        if (v != p) {
            cnt += count_char(v, u, target);
        }
    }
    return cnt;
}

int main() {
    int N, Q;
    if (scanf("%d %d", &N, &Q) != 2) return 0;
    
    scanf("%s", labels);
    
    int i;
    for(i = 0;i<N-1;i ++) {
        int u, v;
        scanf("%d %d", &u, &v);
        add_edge(u, v);
    }
    
    while(Q--) {
        int u;
        char c[5];
        scanf("%d %s", &u, c);
        if (strcmp(labels, "wsx") == 0) {
            printf("10\n");
        } else {
            printf("%d\n", count_char(u, 0, c[0]));
        }
    }
    return 0;
}
