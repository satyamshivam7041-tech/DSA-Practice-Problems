/*
 * 08_Tree_2 Q02: Array max/min replacement operations and sum queries
 * Mandatory: for(i=0;i<n;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <limits.h>

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    
    int orig[105];
    int i;
    for(i=0;i<n;i++) scanf("%d", &orig[i]);
    
    // Simulate up to n-1 operations
    long long sums[105];
    int arr[105];
    int cur_n = n;
    for (int j = 0; j < n; j++) arr[j] = orig[j];
    
    for (int step = 1; step < n; step++) {
        int max_val = INT_MIN, min_val = INT_MAX;
        int max_idx = -1, min_idx = -1;
        
        for (int j = 0; j < cur_n; j++) {
            if (arr[j] > max_val) {
                max_val = arr[j];
                max_idx = j;
            }
            if (arr[j] < min_val) {
                min_val = arr[j];
                min_idx = j;
            }
        }
        
        int diff = max_val - min_val;
        // remove max and min, add diff
        int next_arr[105];
        int next_n = 0;
        for (int j = 0; j < cur_n; j++) {
            if (j != max_idx && j != min_idx) {
                next_arr[next_n++] = arr[j];
            }
        }
        next_arr[next_n++] = diff;
        cur_n = next_n;
        for (int j = 0; j < cur_n; j++) arr[j] = next_arr[j];
        
        long long current_sum = 0;
        for (int j = 0; j < cur_n; j++) current_sum += arr[j];
        sums[step] = current_sum;
    }
    
    while (q--) {
        int k;
        scanf("%d", &k);
        printf("%lld\n", sums[k]);
    }
    return 0;
}
