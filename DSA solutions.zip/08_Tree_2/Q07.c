/*
 * 08_Tree_2 Q07: B-sequence insertion and length queries
 * Mandatory: for(i=0;i<N;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAXV 100005

int count[MAXV];

int main() {
    int N;
    if (scanf("%d", &N) != 1) return 0;
    
    int max_val = 0;
    int i;
    for(i=0;i<N;i++) {
        int x;
        scanf("%d", &x);
        count[x]++;
        if (x > max_val) max_val = x;
    }
    
    int total_len = 0;
    for (int v = 1; v <= max_val; v++) {
        if (v == max_val) {
            if (count[v] > 1) count[v] = 1;
        } else {
            if (count[v] > 2) count[v] = 2;
        }
        total_len += count[v];
    }
    
    int Q;
    if (scanf("%d", &Q) != 1) return 0;
    
    while (Q--) {
        int x;
        scanf("%d", &x);
        if (x > max_val) {
            max_val = x;
            count[x] = 1;
            total_len++;
        } else if (x == max_val) {
            // Already peak, cannot add duplicate peak
        } else {
            if (count[x] < 2) {
                count[x]++;
                total_len++;
            }
        }
        printf("%d\n", total_len);
    }
    
    // Print B-sequence: first pass increasing
    int first = 1;
    for (int v = 1; v <= max_val; v++) {
        if (count[v] > 0) {
            if (!first) printf(" ");
            printf("%d", v);
            first = 0;
        }
    }
    // second pass decreasing
    for (int v = max_val - 1; v >= 1; v--) {
        if (count[v] == 2) {
            if (!first) printf(" ");
            printf("%d", v);
            first = 0;
        }
    }
    printf("\n");
    return 0;
}
