/*
 * 02_Stack Q07: Next smaller element of next greater element
 * Mandatory: if(a[j]>a[i]), for(i=0;i<n;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    long long a[3005];
    int i;
    for (i = 0; i < n; i++) scanf("%lld", &a[i]);
    
    for (i = 0; i < n; i++) {
        int next_greater = -1;
        for (int j = i + 1; j < n; j++) {
            if (a[j] > a[i]) {
                next_greater = j;
                break;
            }
        }
        
        long long ans = -1;
        if (next_greater != -1) {
            for (int k = next_greater + 1; k < n; k++) {
                if (a[k] < a[next_greater]) {
                    ans = a[k];
                    break;
                }
            }
        }
        
        if (i > 0) printf(" ");
        printf("%lld", ans);
    }
    printf("\n");
    return 0;
}
