/*
 * 02_Stack Q10: Postfix to Prefix conversion
 * Mandatory: string postToPre(string post_exp) - but in C
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXN 1000

char stack[MAXN][MAXN];
int top = -1;

int isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

/* postToPre: convert postfix expression to prefix */
void postToPre(char *post_exp, char *result) {
    top = -1;
    int n = strlen(post_exp);
    for (int i = 0; i < n; i++) {
        char c = post_exp[i];
        if (c == ' ') continue;
        if (!isOperator(c)) {
            char tmp[2] = {c, 0};
            strcpy(stack[++top], tmp);
        } else {
            char op1[MAXN], op2[MAXN];
            strcpy(op1, stack[top--]);
            strcpy(op2, stack[top--]);
            char combined[MAXN];
            combined[0] = c;
            combined[1] = 0;
            strcat(combined, op2);
            strcat(combined, op1);
            strcpy(stack[++top], combined);
        }
    }
    strcpy(result, stack[top]);
}

int main() {
    char post[MAXN], result[MAXN];
    while (scanf("%s", post) == 1) {
        postToPre(post, result);
        printf("%s\n", result);
    }
    return 0;
}
