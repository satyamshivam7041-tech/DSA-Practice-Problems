/*
 * 02_Stack Q03: Find min index y > x with arr[x] < arr[y] and arr2[x] > arr2[y]
 * Mandatory: if(arr[x]<arr[y]), if(arr2[x]>arr2[y])
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int digit_sum(int n) {
    if (n < 0) n = -n;
    int s = 0;
    while (n > 0) {
        s += n % 10;
        n /= 10;
    }
    return s;
}

int main() {
    int N, Q;
    if (scanf("%d %d", &N, &Q) != 2) return 0;
    
    int arr[100005];
    int arr2[100005];
    for (int i = 1; i <= N; i++) {
        scanf("%d", &arr[i]);
        arr2[i] = digit_sum(arr[i]);
    }
    
    for (int q = 0; q < Q; q++) {
        int x;
        scanf("%d", &x);
        int ans = -1;
        for (int y = x + 1; y <= N; y++) {
            if (arr[x] < arr[y]) {
                if (arr2[x] > arr2[y]) {
                    ans = y;
                    break;
                }
            }
        }
        if (q > 0) printf(" ");
        printf("%d", ans);
    }
    printf("\n");
    return 0;
}
