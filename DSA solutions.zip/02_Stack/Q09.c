/*
 * 02_Stack Q09: Stack using single queue
 * Mandatory: T1, T2
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 1005

int q[MAXN];
int front = 0, rear = 0;

void enqueue(int val) {
    q[rear++] = val;
}

int dequeue() {
    return q[front++];
}

int queue_size() {
    return rear - front;
}

void push(int val) {
    int s = queue_size();
    enqueue(val);
    for (int i = 0; i < s; i++) {
        enqueue(dequeue());
    }
}

int pop() {
    if (queue_size() == 0) return -1;
    return dequeue();
}

int top() {
    if (queue_size() == 0) return -1;
    return q[front];
}

int main() {
    int T1, T2; /* Mandatory: T1, T2 */
    int n, m;
    if (scanf("%d %d", &n, &m) != 2) return 0;
    T1 = n;
    T2 = m;
    (void)T1; (void)T2;
    
    for (int i = 0; i < n; i++) {
        int val;
        scanf("%d", &val);
        push(val);
    }
    
    printf("top of element %d\n", top());
    
    for (int i = 0; i < m; i++) {
        pop();
    }
    
    printf("top of element %d\n", top());
    return 0;
}
