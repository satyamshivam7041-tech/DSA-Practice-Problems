/*
 * 02_Stack Q02: Merge two reversed stacks
 * Mandatory: void push(int data, mystack* ms); int pop(mystack* ms); void merge(mystack* ms1, mystack* ms2);
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int data;
    struct Node *next;
} Node;

typedef struct mystack {
    Node *first;
} mystack;

void push(int data, mystack* ms) {
    Node *n = (Node*)malloc(sizeof(Node));
    n->data = data;
    n->next = ms->first;
    ms->first = n;
}

int pop(mystack* ms) {
    if (!ms->first) return -1;
    Node *temp = ms->first;
    int val = temp->data;
    ms->first = temp->next;
    free(temp);
    return val;
}

void merge(mystack* ms1, mystack* ms2) {
    if (!ms1->first) {
        ms1->first = ms2->first;
        ms2->first = NULL;
        return;
    }
    Node *cur = ms1->first;
    while (cur->next) cur = cur->next;
    cur->next = ms2->first;
    ms2->first = NULL;
}

int main() {
    int n1, n2;
    if (scanf("%d %d", &n1, &n2) != 2) return 0;
    
    int arr1[1005], arr2[1005];
    for (int i = 0; i < n1; i++) scanf("%d", &arr1[i]);
    for (int i = 0; i < n2; i++) scanf("%d", &arr2[i]);
    
    mystack s1 = {NULL};
    mystack s2 = {NULL};
    
    /* Pushing in forward order and then reversing means:
       Or pushing from end gives the reversed stack directly */
    for (int i = 0; i < n1; i++) push(arr1[i], &s1);
    for (int i = 0; i < n2; i++) push(arr2[i], &s2);
    
    merge(&s1, &s2);
    
    Node *cur = s1.first;
    int first = 1;
    while (cur) {
        if (!first) printf(" ");
        printf("%d", cur->data);
        first = 0;
        cur = cur->next;
    }
    printf("\n");
    return 0;
}
