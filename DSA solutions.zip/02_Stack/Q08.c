/*
 * 02_Stack Q08: Building jump stamina (XOR)
 * Mandatory: st[i]=arr[i]^st[j];
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    long long arr[100005];
    for (int i = 0; i < n; i++) scanf("%lld", &arr[i]);
    
    long long st[100005];
    long long max_stamina = 0;
    
    for (int i = n - 1; i >= 0; i--) {
        int next_higher = -1;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] > arr[i]) {
                next_higher = j;
                break;
            }
        }
        
        if (next_higher != -1) {
            int j = next_higher;
            st[i]=arr[i]^st[j];
        } else {
            st[i] = arr[i];
        }
        
        if (st[i] > max_stamina) {
            max_stamina = st[i];
        }
    }
    
    printf("%lld\n", max_stamina);
    return 0;
}
