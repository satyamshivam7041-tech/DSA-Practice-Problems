/*
 * 02_Stack Q06: Stock Span Problem
 * Mandatory: void calculateSpan(int price[], int n, int S[])
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

void calculateSpan(int price[], int n, int S[]) {
    int st[n]; /* stack of indices */
    int top = -1;
    S[0] = 1;
    st[++top] = 0;
    for (int i = 1; i < n; i++) {
        while (top >= 0 && price[st[top]] <= price[i]) top--;
        S[i] = (top < 0) ? (i + 1) : (i - st[top]);
        st[++top] = i;
    }
}

int main() {
    int n;
    scanf("%d", &n);
    int price[n], S[n];
    for (int i = 0; i < n; i++) scanf("%d", &price[i]);
    calculateSpan(price, n, S);
    for (int i = 0; i < n; i++) {
        if (i) printf(" ");
        printf("%d", S[i]);
    }
    printf("\n");
    return 0;
}
