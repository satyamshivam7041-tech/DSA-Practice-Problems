/*
 * 02_Stack Q05: Balanced Brackets check using Stack
 * Mandatory: stack
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAXN 10005

char stack[MAXN];
int top = -1;

int isBalanced(char *exp) {
    top = -1;
    for (int i = 0; exp[i]; i++) {
        char c = exp[i];
        if (c == '(' || c == '[' || c == '{') {
            stack[++top] = c;
        } else if (c == ')') {
            if (top < 0 || stack[top] != '(') return 0;
            top--;
        } else if (c == ']') {
            if (top < 0 || stack[top] != '[') return 0;
            top--;
        } else if (c == '}') {
            if (top < 0 || stack[top] != '{') return 0;
            top--;
        }
    }
    return top == -1;
}

int main() {
    char exp[MAXN];
    while (scanf("%s", exp) == 1) {
        printf("%s\n", isBalanced(exp) ? "Balanced" : "Not Balanced");
    }
    return 0;
}
