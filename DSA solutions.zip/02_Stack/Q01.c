/*
 * 02_Stack Q01: A and B game
 * Mandatory: if(a[i]>a[j])
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    int a[1005], b[1005];
    for (int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
        b[i] = a[i];
    }
    
    int a_start = 0, a_end = n - 1;
    int b_start = 0, b_end = n - 1;
    int first = 1;
    
    while (a_start <= a_end && b_start <= b_end) {
        int x = a[a_start];
        int y = b[b_end];
        
        if (!first) printf(" ");
        first = 0;
        
        if (x > y) { /* mandatory: if(a[i]>a[j]) */
            printf("1");
            b_end--;
        } else if (x < y) {
            printf("2");
            a_start++;
        } else {
            printf("0");
            a_start++;
            b_end--;
        }
    }
    printf("\n");
    return 0;
}
