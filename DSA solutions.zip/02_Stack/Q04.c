/*
 * 02_Stack Q04: Two stacks in an array
 * Mandatory: void push1(int x), void push2(int x), int pop1(), int pop2()
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define SIZE 20

int arr[SIZE];
int top1 = -1;
int top2 = SIZE;

void push1(int x) {
    if (top1 < top2 - 1) {
        top1++;
        arr[top1] = x;
    }
}

void push2(int x) {
    if (top1 < top2 - 1) {
        top2--;
        arr[top2] = x;
    }
}

int pop1() {
    if (top1 >= 0) {
        int x = arr[top1];
        top1--;
        return x;
    }
    return -1;
}

int pop2() {
    if (top2 < SIZE) {
        int x = arr[top2];
        top2++;
        return x;
    }
    return -1;
}

int main() {
    int val;
    int count = 0;
    while (scanf("%d", &val) == 1 && count < 5) {
        if (count % 2 == 0) {
            push1(val);
        } else {
            push2(val);
        }
        count++;
    }
    
    printf("Popped element from stack1 is:%d\n", pop1());
    printf("Popped element from stack2 is:%d\n", pop2());
    return 0;
}
