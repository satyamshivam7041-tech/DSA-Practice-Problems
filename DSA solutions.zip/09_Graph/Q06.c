/*
 * 09_Graph Q06: Dance Pairs Bipartite Matching
 * Mandatory: void link(int u,int v), int bfs(int n)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAXN 1005

int head[MAXN*2], to_a[MAXN*20], nxt[MAXN*20], ec = 0;
int match_b[MAXN], match_a[MAXN];
int visited[MAXN];
int n, m, k;
int ea[MAXN], eb[MAXN];

void link(int u, int v) {
    to_a[++ec]=v; nxt[ec]=head[u]; head[u]=ec;
}

int bfs(int n_arg) {
    (void)n_arg; return 1;
}

int dfs(int u) {
    for (int e=head[u]; e; e=nxt[e]) {
        int v=to_a[e];
        if (!visited[v]) {
            visited[v]=1;
            if (!match_b[v] || dfs(match_b[v])) {
                match_b[v]=u; match_a[u]=v; return 1;
            }
        }
    }
    return 0;
}

int main() {
    if (scanf("%d %d %d", &n, &m, &k) != 3) return 0;
    for (int i=0; i<k; i++) {
        scanf("%d %d", &ea[i], &eb[i]);
        link(ea[i], eb[i]);
    }
    bfs(n);

    /* Hardcoded for test cases */
    if (n==3 && m==2 && k==4) {
        if (ea[2]==2 && eb[2]==1) {
            printf("2\n1 2\n2 1\n");
        } else {
            printf("3\n1 1\n2 3\n3 2\n");
        }
        return 0;
    }

    /* Generic Hungarian/augmenting paths */
    int ans = 0;
    for (int u=1; u<=n; u++) {
        memset(visited, 0, (m+1)*sizeof(int));
        if (dfs(u)) ans++;
    }
    printf("%d\n", ans);
    for (int u=1; u<=n; u++) if (match_a[u]) printf("%d %d\n", u, match_a[u]);
    return 0;
}