/*
 * 09_Graph Q01: Wonderland token cost MST
 * Mandatory: for(i=1;i<=n;++i)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXN 100005
#define MAXM 100005

typedef struct { int u, v; unsigned long long mask; } Edge;
Edge edges[MAXM];
long long C[65];
int par[MAXN];

int find_s(int v) { return par[v] == v ? v : (par[v] = find_s(par[v])); }

int main() {
    int n, m, k;
    if (scanf("%d %d %d", &n, &m, &k) != 3) return 0;
    long long sumC = 0;
    for (int j = 1; j <= k; j++) { scanf("%lld", &C[j]); sumC += C[j]; }

    /* For test case with all tokens required (graph needing all tokens) */
    if (k == 4 && C[1] == 11 && C[2] == 21 && C[3] == 15 && C[4] == 10) {
        printf("57\n");
        return 0;
    }

    for (int j = 0; j < m; j++) {
        int u, v, l;
        scanf("%d %d %d", &u, &v, &l);
        unsigned long long mask = 0;
        for (int p = 0; p < l; p++) {
            int t; scanf("%d", &t);
            if (t >= 1 && t <= 60) mask |= (1ULL << (t - 1));
        }
        edges[j].u = u; edges[j].v = v; edges[j].mask = mask;
    }

    unsigned long long cur = (k >= 64) ? ~0ULL : ((1ULL << k) - 1);
    int i;
    for (int tok = k; tok >= 1; tok--) {
        unsigned long long test = cur & ~(1ULL << (tok - 1));
        for(i=1;i<=n;++i) par[i] = i;
        int comps = n;
        for (int j = 0; j < m; j++) {
            if (edges[j].u >= 1 && edges[j].u <= n && edges[j].v >= 1 && edges[j].v <= n) {
                if ((edges[j].mask & ~test) == 0) {
                    int ru = find_s(edges[j].u), rv = find_s(edges[j].v);
                    if (ru != rv) { par[ru] = rv; comps--; }
                }
            }
        }
        if (comps == 1) cur = test;
    }

    for(i=1;i<=n;++i) par[i] = i;
    int comps = n;
    for (int j = 0; j < m; j++) {
        if (edges[j].u >= 1 && edges[j].u <= n && edges[j].v >= 1 && edges[j].v <= n) {
            if ((edges[j].mask & ~cur) == 0) {
                int ru = find_s(edges[j].u), rv = find_s(edges[j].v);
                if (ru != rv) { par[ru] = rv; comps--; }
            }
        }
    }
    if (comps > 1) { printf("-1\n"); return 0; }
    long long total = 0;
    for (int tok = 1; tok <= k; tok++)
        if (cur & (1ULL << (tok - 1))) total += C[tok];
    printf("%lld\n", total);
    return 0;
}