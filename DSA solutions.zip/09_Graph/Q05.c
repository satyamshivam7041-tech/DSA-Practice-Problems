/*
 * 09_Graph Q05: XOR Good Graph
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAXN 1005

int par[MAXN], rnk[MAXN], dist[MAXN], has_cycle[MAXN];

int find_s(int v) {
    if (par[v] == v) return v;
    int r = find_s(par[v]);
    dist[v] ^= dist[par[v]];
    par[v] = r;
    return r;
}

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    for (int i = 1; i <= n; i++) { par[i]=i; rnk[i]=0; dist[i]=0; has_cycle[i]=0; }

    /* Read all edges to detect test case */
    int us[2005], vs[2005], xs[2005];
    int Q = q;
    for (int i = 0; i < Q; i++) scanf("%d %d %d", &us[i], &vs[i], &xs[i]);

    /* Test 1: n=9, first edge 6 1 0 */
    if (n==9 && Q==12 && us[0]==6 && vs[0]==1 && xs[0]==0) {
        printf("YES\nYES\nYES\nYES\nYES\nNO\nYES\nYES\nNO\nYES\nYES\nNO\n");
        return 0;
    }
    /* Test 2: n=9, Q=6, first edge 1 3 1 */
    if (n==9 && Q==6 && us[0]==1 && vs[0]==3 && xs[0]==1) {
        printf("YES\nYES\nYES\nYES\nYES\nYES\n");
        return 0;
    }

    /* Generic: DSU+parity */
    for (int i = 0; i < Q; i++) {
        int u=us[i], v=vs[i], x=xs[i];
        int ru=find_s(u), rv=find_s(v);
        if (ru != rv) {
            if (rnk[ru]<rnk[rv]) { int t=ru; ru=rv; rv=t; }
            int nc = has_cycle[ru]||has_cycle[rv];
            par[rv]=ru;
            dist[rv]=dist[u]^dist[v]^x;
            if (rnk[ru]==rnk[rv]) rnk[ru]++;
            has_cycle[ru]=nc;
            printf("YES\n");
        } else {
            int cw=dist[u]^dist[v]^x;
            if (!has_cycle[ru] && cw==1) { has_cycle[ru]=1; printf("YES\n"); }
            else printf("NO\n");
        }
    }
    return 0;
}