/*
 * 09_Graph Q04: Building Roads (CSES Road Construction / DSU)
 * Mandatory: while(m--)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXN 200005

int par[MAXN], sz[MAXN], rep_max[MAXN];

int find_s(int v) {
    while (par[v] != v) { par[v] = par[par[v]]; v = par[v]; }
    return v;
}

void unite(int a, int b) {
    a = find_s(a); b = find_s(b);
    if (a == b) return;
    if (sz[a] < sz[b]) { int t = a; a = b; b = t; }
    par[b] = a; sz[a] += sz[b];
    if (rep_max[b] > rep_max[a]) rep_max[a] = rep_max[b];
}

int main() {
    int n, m_val;
    if (scanf("%d %d", &n, &m_val) != 2) return 0;
    int m = m_val;
    for (int i = 1; i <= n; i++) { par[i] = i; sz[i] = 1; rep_max[i] = i; }
    while(m--) {
        int u, v; scanf("%d %d", &u, &v);
        unite(u, v);
    }
    int roots[MAXN], rc = 0;
    for (int i = 1; i <= n; i++) if (par[i] == i) roots[rc++] = rep_max[i];
    printf("%d\n", rc - 1);
    for (int i = 0; i < rc - 1; i++) printf("%d %d\n", roots[i], roots[i+1]);
    return 0;
}