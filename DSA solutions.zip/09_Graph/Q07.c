/*
 * 09_Graph Q07: Road Construction (CSES) - DSU components + max size
 * Mandatory: int join(int i,int j)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 200005

int par[MAXN], sz[MAXN];
int num_comp, max_sz;

int find_s(int v) {
    while (par[v]!=v) { par[v]=par[par[v]]; v=par[v]; }
    return v;
}

int join(int i, int j) {
    int a=find_s(i), b=find_s(j);
    if (a==b) return 0;
    if (sz[a]<sz[b]) { int t=a; a=b; b=t; }
    par[b]=a; sz[a]+=sz[b];
    if (sz[a]>max_sz) max_sz=sz[a];
    num_comp--;
    return 1;
}

int main() {
    int n, m;
    if (scanf("%d %d", &n, &m) != 2) return 0;
    num_comp=n; max_sz=1;
    for (int i=1;i<=n;i++) { par[i]=i; sz[i]=1; }
    for (int k=0;k<m;k++) {
        int u,v; scanf("%d %d",&u,&v);
        join(u,v);
        printf("%d %d\n", num_comp, max_sz);
    }
    return 0;
}