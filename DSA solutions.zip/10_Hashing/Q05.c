/*
 * 10_Hashing Q05: Max frequency character in string
 * Mandatory: for(i=0;i<l;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 * Input: one line string. Output: char with max frequency and its count.
 */
#include <stdio.h>
#include <string.h>

int main() {
    char s[10005];
    if (fgets(s, sizeof(s), stdin) == NULL) return 0;
    int l = (int)strlen(s);
    int freq[256] = {0};
    int i;
    for(i=0;i<l;i++) freq[(unsigned char)s[i]]++;
    int max_freq = 0;
    char max_char = 0;
    for(i=0;i<256;i++) {
        if(freq[i] > max_freq || (freq[i] == max_freq && i < (unsigned char)max_char)) {
            max_freq = freq[i];
            max_char = (char)i;
        }
    }
    printf("%c %d\n", max_char, max_freq);
    return 0;
}