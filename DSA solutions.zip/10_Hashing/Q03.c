/*
 * 10_Hashing Q03: Festival spending - top-3 sum per item name per group
 * Mandatory: while(t--)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 * Input: t (number of groups), then each group: size n, then n lines of "name amount"
 * Output: for each group, the name with max top-3-sum and that sum
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXITEMS 1005
#define MAXNAME 50

typedef struct {
    char name[MAXNAME];
    int amounts[1005];
    int cnt;
} Item;

Item items[MAXITEMS];
int num_items;

int find_item(const char *nm) {
    for(int i=0;i<num_items;i++)
        if(strcmp(items[i].name,nm)==0) return i;
    strcpy(items[num_items].name,nm);
    items[num_items].cnt=0;
    return num_items++;
}

int cmp_desc(const void *a, const void *b) { return *(int*)b - *(int*)a; }

int main() {
    int t;
    if(scanf("%d",&t)!=1) return 0;
    while(t--) {
        num_items=0;
        int g; scanf("%d",&g);
        for(int i=0;i<g;i++) {
            char nm[MAXNAME]; int val;
            scanf("%s %d",nm,&val);
            int idx=find_item(nm);
            items[idx].amounts[items[idx].cnt++]=val;
        }
        char best_name[MAXNAME]; long long best_sum=-1;
        for(int i=0;i<num_items;i++) {
            qsort(items[i].amounts,items[i].cnt,sizeof(int),cmp_desc);
            long long s=0;
            int top = items[i].cnt < 3 ? items[i].cnt : 3;
            for(int j=0;j<top;j++) s+=items[i].amounts[j];
            if(s>best_sum || (s==best_sum && strcmp(items[i].name,best_name)<0)) {
                best_sum=s; strcpy(best_name,items[i].name);
            }
        }
        printf("%s %lld\n",best_name,best_sum);
    }
    return 0;
}