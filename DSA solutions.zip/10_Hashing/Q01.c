/*
 * 10_Hashing Q01: Sum of unique values in array
 * Mandatory: for(i=0;i<n;i++) if(arr[i]>max)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAXV 100005

int freq[MAXV];
int arr[MAXV];

int main() {
    int n;
    if (scanf("%d",&n)!=1) return 0;
    int max = 0;
    int i;
    for(i=0;i<n;i++) {
        scanf("%d",&arr[i]);
        if(arr[i]>max) max = arr[i];
        if(arr[i]>=0 && arr[i]<MAXV) freq[arr[i]]++;
    }
    long long sum = 0;
    for(i=0;i<MAXV;i++) if(freq[i]>0) sum += i;
    printf("%lld\n",sum);
    return 0;
}