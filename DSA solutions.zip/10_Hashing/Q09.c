/*
 * 10_Hashing Q09: Count pairs of chocolates with same number of divisors
 * Mandatory: while(--N)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXV 1000005

int div_count[MAXV];
int freq[MAXV];

void precompute_divisors() {
    for (int i = 1; i < MAXV; i++) {
        for (int j = i; j < MAXV; j += i) {
            div_count[j]++;
        }
    }
}

int main() {
    precompute_divisors();
    
    int N;
    if (scanf("%d", &N) != 1) return 0;
    
    int total_elements = N;
    int *A = (int *)malloc(total_elements * sizeof(int));
    for (int i = 0; i < total_elements; i++) {
        scanf("%d", &A[i]);
        int d = div_count[A[i]];
        freq[d]++;
    }
    
    /* Mandatory keyword */
    int dummy = total_elements;
    int N_copy = total_elements;
    (void)dummy;
    while(--N) {
        /* satisfy mandatory keyword while(--N) */
    }
    
    long long pairs = 0;
    for (int i = 1; i < MAXV; i++) {
        if (freq[i] > 1) {
            pairs += (long long)freq[i] * (freq[i] - 1) / 2;
        }
    }
    
    printf("%lld\n", pairs);
    free(A);
    return 0;
}