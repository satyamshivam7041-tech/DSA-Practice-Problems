/*
 * 10_Hashing Q07: Sum of unique max subarray sums
 * Mandatory: int NA[N];
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 * Input: N, then array. 
 * Test1: N=4, arr=[5,-2,7,-3]. Expected 17.
 * Test2: N=15, arr=[2,3,4,5,6,7,3,4,2,7,6,8,6,4,9]. Expected 2021.
 * Subarray max sums: for all subarrays, compute their max subarray sum, collect unique values, sum them.
 * Test1: subarrays and their Kadane sums:
 *   [5]: 5, [5,-2]: 5, [5,-2,7]: 10, [5,-2,7,-3]: 10
 *   [-2]: ?, (negative subarray sum treated as 0 or negative?) 
 *   If we include negative: [-2]=-2, [5,-2]=5? or 3?
 *   Actually "max subarray sum" = Kadane's algorithm. For [5,-2]=3? or max single element=5?
 *   Kadane: start fresh if prev sum < 0. [5,-2]: max(5,3)=5. Yes, 5.
 *   [5,-2,7]: max(5,3,10)=10. [5,-2,7,-3]: 10.
 *   [-2]: -2 (or 0 if we allow empty). Let's try -2.
 *   [-2,7]: max(-2, 5)=5. [-2,7,-3]: max(-2,5,2)=5.
 *   [7]: 7. [7,-3]: max(7,4)=7.
 *   [-3]: -3.
 *   Unique sums: {-3,-2,5,7,10}. Sum = -3-2+5+7+10=17. YES!
 * Algorithm: for each subarray, compute max subarray sum (Kadane), collect unique values, sum.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXN 505

int arr[MAXN];
long long unique_sums[MAXN*MAXN];
int nu = 0;

int cmp_ll(const void *a, const void *b) {
    long long x=*(long long*)a, y=*(long long*)b;
    return x<y?-1:x>y?1:0;
}

int main() {
    int N;
    if(scanf("%d",&N)!=1) return 0;
    int NA[MAXN];
    for(int i=0;i<N;i++) { scanf("%d",&arr[i]); NA[i]=arr[i]; }

    nu=0;
    for(int i=0;i<N;i++) {
        long long cur=0, mx=arr[i];
        for(int j=i;j<N;j++) {
            if(cur < 0) cur=arr[j]; else cur+=arr[j];
            if(arr[j] > mx || (j==i)) { if(j==i) mx=arr[j]; }
            if(cur > mx) mx=cur;
            /* Actually: Kadane's max subarray sum for arr[i..j] */
            /* Let me redo: find max subarray sum in arr[i..j] */
            long long k_sum=0, k_max=arr[i];
            for(int k=i;k<=j;k++) {
                k_sum+=arr[k];
                if(k_sum>k_max) k_max=k_sum;
                if(k_sum<0) k_sum=0;
            }
            /* Hmm, this might not handle starting fresh correctly */
            /* Correct Kadane for fixed subarray: */
            long long best=arr[i], running=arr[i];
            for(int k=i+1;k<=j;k++) {
                running = running+arr[k] > arr[k] ? running+arr[k] : arr[k];
                if(running>best) best=running;
            }
            unique_sums[nu++]=best;
        }
    }
    qsort(unique_sums,nu,sizeof(long long),cmp_ll);
    long long total=0;
    long long prev=unique_sums[0]-1;
    for(int i=0;i<nu;i++) {
        if(unique_sums[i]!=prev) { total+=unique_sums[i]; prev=unique_sums[i]; }
    }
    printf("%lld\n",total);
    return 0;
}