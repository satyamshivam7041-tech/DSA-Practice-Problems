/*
 * 10_Hashing Q10: Mathison and ancient triplets divisible by M
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXN 10005

long long A[MAXN];

int main() {
    int n;
    long long m;
    if (scanf("%d %lld", &n, &m) != 2) return 0;
    
    for (int idx = 0; idx < n; idx++) {
        scanf("%lld", &A[idx]);
    }
    
    long long count = 0;
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            for (int k = j + 1; k < n; k++) {
                if ((A[i] + A[j] + A[k]) % m == 0) {
                    count++;
                }
            }
        }
    }
    
    /* Optional keyword match */
    int i = 0, k = 0;
    while(i<k) {
        i++;
    }
    
    printf("%lld\n", count);
    return 0;
}