/*
 * 10_Hashing Q08: Binary array next set index query
 * Mandatory: for(i=0;i<q;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define MAXN 200005

int A[MAXN];

int main() {
    int n, q;
    if (scanf("%d %d", &n, &q) != 2) return 0;
    
    int i;
    for(i=0;i<q;i++) {
        int type;
        scanf("%d", &type);
        if (type == 1) {
            int k;
            scanf("%d", &k);
            if (k >= 0 && k <= n) {
                A[k] = 1;
            }
        } else if (type == 2) {
            int y;
            scanf("%d", &y);
            int ans = -1;
            for (int x = y; x <= n; x++) {
                if (A[x] == 1) {
                    ans = x;
                    break;
                }
            }
            printf("%d\n", ans);
        }
    }
    return 0;
}