/*
 * 03_Queue Q01: Priority Queue - product of top 3 largest values in range [1,i]
 * For each index i, print product of 3 largest distinct-index values in A[0..i]
 * If less than 3 elements, print -1.
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);
    long long a[n];
    for (int i = 0; i < n; i++) scanf("%lld", &a[i]);

    /* Maintain top 3 as we scan */
    long long top3[3] = {-1,-1,-1};
    for (int i = 0; i < n; i++) {
        /* Insert a[i] into top3 */
        long long v = a[i];
        if (v > top3[0]) { top3[2]=top3[1]; top3[1]=top3[0]; top3[0]=v; }
        else if (v > top3[1]) { top3[2]=top3[1]; top3[1]=v; }
        else if (v > top3[2]) { top3[2]=v; }

        if (i < 2) { printf("-1\n"); }
        else { printf("%lld\n", top3[0]*top3[1]*top3[2]); }
    }
    return 0;
}
