/*
 * 03_Queue Q07: Circular Queue using Linked List, print one element per line
 * Mandatory: void enqueue(int d), struct node* next;, n = (struct node*)malloc(sizeof(struct node));
 * struct node *f = NULL; struct node *r = NULL; n->data = d; n->next = NULL; struct node* t;
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node* next;
};

struct node *f = NULL;
struct node *r = NULL;

void enqueue(int d) {
    struct node *n = (struct node*)malloc(sizeof(struct node));
    n->data = d;
    n->next = NULL;
    if (f == NULL && r == NULL) {
        f = r = n;
        r->next = f;
    } else {
        r->next = n;
        r = n;
        r->next = f;
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        enqueue(x);
    }
    
    struct node* t;
    t = f;
    if (t != NULL) {
        do {
            printf("%d\n", t->data);
            t = t->next;
        } while (t != f);
    }
    return 0;
}
