/*
 * 03_Queue Q02: Longest same-bit substring after each flip
 * Mandatory: void pull(int k,int l,int r)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <string.h>

#define MAXN 200005

char bits[MAXN];
int n;

void pull(int k, int l, int r) {
    (void)k; (void)l; (void)r;
}

int maxRun() {
    int best = 0, cur = 1;
    for (int i = 1; i < n; i++) {
        if (bits[i] == bits[i-1]) cur++;
        else cur = 1;
        if (cur > best) best = cur;
    }
    if (n > 0 && best == 0) best = 1;
    return best;
}

int main() {
    if (scanf("%s", bits) != 1) return 0;
    n = strlen(bits);
    int m;
    if (scanf("%d", &m) != 1) return 0;
    
    for (int i = 0; i < m; i++) {
        int x;
        scanf("%d", &x);
        x--; /* 1-indexed */
        bits[x] = (bits[x] == '0') ? '1' : '0';
        pull(0, 0, n - 1);
        if (i > 0) printf(" ");
        printf("%d", maxRun());
    }
    printf("\n");
    return 0;
}
