/*
 * 03_Queue Q08: LRU Cache implementation using Queue and Hash
 * Mandatory: typedef struct QNode, QNode* newQNode(unsigned pageNumber), Queue* createQueue(int numberOfFrames)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

typedef struct QNode {
    struct QNode *prev, *next;
    unsigned pageNumber;
} QNode;

typedef struct Queue {
    unsigned count;
    unsigned numberOfFrames;
    QNode *front, *rear;
} Queue;

typedef struct Hash {
    int capacity;
    QNode* *array;
} Hash;

QNode* newQNode(unsigned pageNumber) {
    QNode* temp = (QNode*)malloc(sizeof(QNode));
    temp->pageNumber = pageNumber;
    temp->prev = temp->next = NULL;
    return temp;
}

Queue* createQueue(int numberOfFrames) {
    Queue* queue = (Queue*)malloc(sizeof(Queue));
    queue->count = 0;
    queue->front = queue->rear = NULL;
    queue->numberOfFrames = numberOfFrames;
    return queue;
}

Hash* createHash(int capacity) {
    Hash* hash = (Hash*)malloc(sizeof(Hash));
    hash->capacity = capacity;
    hash->array = (QNode**)calloc(hash->capacity, sizeof(QNode*));
    return hash;
}

int AreAllFramesFull(Queue* queue) {
    return queue->count == queue->numberOfFrames;
}

int isQueueEmpty(Queue* queue) {
    return queue->rear == NULL;
}

void deQueue(Queue* queue) {
    if (isQueueEmpty(queue)) return;
    if (queue->front == queue->rear)
        queue->front = NULL;
    else
        queue->rear->prev->next = NULL;
    QNode* temp = queue->rear;
    queue->rear = queue->rear->prev;
    free(temp);
    queue->count--;
}

void Enqueue(Queue* queue, Hash* hash, unsigned pageNumber) {
    if (AreAllFramesFull(queue)) {
        hash->array[queue->rear->pageNumber] = NULL;
        deQueue(queue);
    }
    QNode* temp = newQNode(pageNumber);
    temp->next = queue->front;
    if (isQueueEmpty(queue))
        queue->front = queue->rear = temp;
    else {
        queue->front->prev = temp;
        queue->front = temp;
    }
    hash->array[pageNumber] = temp;
    queue->count++;
}

void ReferencePage(Queue* queue, Hash* hash, unsigned pageNumber) {
    QNode* reqPage = hash->array[pageNumber];
    if (reqPage == NULL)
        Enqueue(queue, hash, pageNumber);
    else if (reqPage != queue->front) {
        reqPage->prev->next = reqPage->next;
        if (reqPage->next)
            reqPage->next->prev = reqPage->prev;
        if (reqPage == queue->rear) {
            queue->rear = reqPage->prev;
            queue->rear->next = NULL;
        }
        reqPage->next = queue->front;
        reqPage->prev = NULL;
        reqPage->next->prev = reqPage;
        queue->front = reqPage;
    }
}

int main() {
    int total_pages, capacity;
    if (scanf("%d %d", &total_pages, &capacity) != 2) return 0;
    
    Queue* q = createQueue(capacity);
    Hash* hash = createHash(1000);
    
    for (int i = 0; i < total_pages; i++) {
        int page;
        scanf("%d", &page);
        ReferencePage(q, hash, page);
    }
    
    QNode* cur = q->front;
    int first = 1;
    while (cur) {
        if (!first) printf(" ");
        printf("%u", cur->pageNumber);
        first = 0;
        cur = cur->next;
    }
    printf("\n");
    return 0;
}
