/*
 * 03_Queue Q03: Dequeue elements one by one and display remaining queue
 * Mandatory: void enqueue(int data), for(i=front;i<=rear;i++), void dequeue()
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 105

int queue[MAXN];
int front = 0, rear = -1;

void enqueue(int data) {
    queue[++rear] = data;
}

void dequeue() {
    if (front <= rear) front++;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    for (int k = 0; k < n; k++) {
        int x;
        scanf("%d", &x);
        enqueue(x);
    }
    
    printf("Dequeuing elements:\n");
    int i;
    while (front < rear) {
        dequeue();
        for (i = front; i <= rear; i++) {
            printf("%d ", queue[i]);
        }
        printf("\n");
    }
    return 0;
}
