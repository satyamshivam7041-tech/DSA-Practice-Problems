/*
 * 03_Queue Q10: Reverse a Queue
 * Mandatory: void reverse(), reverse();
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 105

int queue[MAXN];
int front = 0, rear = -1;

void enqueue(int data, int l) {
    (void)l;
    queue[++rear] = data;
}

void reverse() {
    int i = front, j = rear;
    while (i < j) {
        int temp = queue[i];
        queue[i] = queue[j];
        queue[j] = temp;
        i++;
        j--;
    }
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        enqueue(x, n);
    }
    
    printf("Queue:");
    for (int i = front; i <= rear; i++) {
        printf("%d ", queue[i]);
    }
    printf("\n");
    
    reverse();
    
    printf("Reversed Queue:");
    int first = 1;
    for (int i = front; i <= rear; i++) {
        if (!first) printf(" ");
        printf("%d", queue[i]);
        first = 0;
    }
    printf("\n");
    return 0;
}
