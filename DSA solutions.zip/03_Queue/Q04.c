/*
 * 03_Queue Q04: Queue using linked list, print queue then dequeue one element
 * Mandatory: void enqueue(int d), struct node* new_n;, new_n = (struct node*)malloc(sizeof(struct node));
 * struct node *rear = NULL; struct node *front = NULL;
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

struct node *rear = NULL;
struct node *front = NULL;

void enqueue(int d) {
    struct node* new_n;
    new_n = (struct node*)malloc(sizeof(struct node));
    new_n->data = d;
    new_n->next = NULL;
    if (rear == NULL) {
        front = rear = new_n;
        return;
    }
    rear->next = new_n;
    rear = new_n;
}

void dequeue() {
    if (front == NULL) return;
    struct node *temp = front;
    front = front->next;
    if (front == NULL) rear = NULL;
    free(temp);
}

void display() {
    struct node *cur = front;
    while (cur) {
        printf("%d ", cur->data);
        cur = cur->next;
    }
    printf("\n");
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        enqueue(x);
    }
    display();
    dequeue();
    display();
    return 0;
}
