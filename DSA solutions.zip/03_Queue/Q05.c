/*
 * 03_Queue Q05: Insert elements and display after each enqueue
 * Mandatory: void enqueue(int data), for(i=front;i<=rear;i++)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>

#define MAXN 105

int queue[MAXN];
int front = 0, rear = -1;

void enqueue(int data) {
    queue[++rear] = data;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    int val[MAXN];
    for (int k = 0; k < n; k++) {
        scanf("%d", &val[k]);
    }
    
    int i;
    for (int k = 0; k < n; k++) {
        if (k == 0) {
            printf("Enqueuing %d\n", val[k]);
        } else {
            for (i = front; i <= rear; i++) {
                printf("%d ", queue[i]);
            }
            printf("Enqueuing %d\n", val[k]);
        }
        enqueue(val[k]);
    }
    
    for (i = front; i <= rear; i++) {
        if (i > front) printf(" ");
        printf("%d", queue[i]);
    }
    printf("\n");
    return 0;
}
