/*
 * 03_Queue Q09: Circular Queue, dequeue two elements step by step
 * Mandatory: void enqueue(int d), struct node* next;, n = (struct node*)malloc(sizeof(struct node));
 * struct node *f = NULL; struct node *r = NULL; n->data = d; n->next = NULL; struct node* t;
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node* next;
};

struct node *f = NULL;
struct node *r = NULL;

void enqueue(int d) {
    struct node *n = (struct node*)malloc(sizeof(struct node));
    n->data = d;
    n->next = NULL;
    if (f == NULL && r == NULL) {
        f = r = n;
        r->next = f;
    } else {
        r->next = n;
        r = n;
        r->next = f;
    }
}

void dequeue() {
    struct node* t;
    t = f;
    if (f == NULL && r == NULL) return;
    if (f == r) {
        f = r = NULL;
        free(t);
    } else {
        f = f->next;
        r->next = f;
        free(t);
    }
}

void display() {
    struct node* t;
    t = f;
    if (t != NULL) {
        do {
            printf("%d ", t->data);
            t = t->next;
        } while (t != f);
    }
    printf("\n");
}

int main() {
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        enqueue(x);
    }
    
    display();
    dequeue();
    display();
    dequeue();
    display();
    return 0;
}
