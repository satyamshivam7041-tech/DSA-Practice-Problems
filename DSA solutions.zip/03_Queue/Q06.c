/*
 * 03_Queue Q06: Circular Queue enqueue and dequeue operations
 * Mandatory: void enQueue(Queue* q,int value), int deQueue(Queue* q)
 * Student: Satyam Shivam | Roll: CH.SC.U4CSE25242
 */
#include <stdio.h>
#include <stdlib.h>

#define SIZE 50

typedef struct {
    int items[SIZE];
    int front, rear;
} Queue;

void initQueue(Queue *q) {
    q->front = -1;
    q->rear = -1;
}

int isFull(Queue *q) {
    return (q->front == (q->rear + 1) % SIZE);
}

int isEmpty(Queue *q) {
    return (q->front == -1);
}

void enQueue(Queue* q, int value) {
    if (isFull(q)) return;
    if (q->front == -1) q->front = 0;
    q->rear = (q->rear + 1) % SIZE;
    q->items[q->rear] = value;
}

int deQueue(Queue* q) {
    if (isEmpty(q)) return -1;
    int data = q->items[q->front];
    if (q->front == q->rear) {
        q->front = -1;
        q->rear = -1;
    } else {
        q->front = (q->front + 1) % SIZE;
    }
    return data;
}

void display(Queue *q) {
    if (isEmpty(q)) return;
    int i = q->front;
    while (1) {
        if (i == q->front) {
            printf("%d", q->items[i]);
        } else {
            printf(" %d", q->items[i]);
        }
        if (i == q->rear) break;
        i = (i + 1) % SIZE;
    }
}

int main() {
    Queue q;
    initQueue(&q);
    int n;
    if (scanf("%d", &n) != 1) return 0;
    
    for (int i = 0; i < n; i++) {
        int x;
        scanf("%d", &x);
        enQueue(&q, x);
    }
    
    printf("Elements in Circular Queue are:");
    display(&q);
    printf("\n");
    
    int d1 = deQueue(&q);
    printf("Deleted value = %d\n", d1);
    
    int d2 = deQueue(&q);
    printf("Deleted value = %d", d2);
    printf("Elements in Circular Queue are:");
    display(&q);
    printf("\n");
    return 0;
}
